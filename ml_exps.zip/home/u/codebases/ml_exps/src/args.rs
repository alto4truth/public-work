use clap::{Parser, Subcommand};

// --- Argument Parsing ---
#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
pub struct Args {
    /// Select a sub-command.
    #[clap(subcommand)]
    pub command: Command,
}

#[derive(Subcommand, Debug)]
pub enum Command {
    /// Train the model on the given dataset
    Train {
        /// Path to a training data JSON file
        #[clap(short, long)]
        train_data: String,

        /// Force using the CPU backend.
        #[clap(long, conflicts_with = "cuda")]
        cpu: bool,

        /// Force using the CUDA backend (requires cuda_backend feature).
        #[clap(long, conflicts_with = "cpu")]
        cuda: bool,
    },
    /// Run interactive inference with a checkpoint
    Infer {
        /// Path to a .safetensors checkpoint (defaults to model_checkpoint.safetensors)
        #[clap(short, long, default_value = "model_checkpoint.safetensors")]
        checkpoint: String,

        /// Force using the CPU backend.
        #[clap(long, conflicts_with = "cuda")]
        cpu: bool,

        /// Force using the CUDA backend (requires cuda_backend feature).
        #[clap(long, conflicts_with = "cpu")]
        cuda: bool,
    },
}
