use clap::Parser;

// --- Argument Parsing ---
#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
pub struct Args {
    /// Optional path to a training data file.
    #[clap(short, long)] // Use -t or --train-data
    pub train_data: Option<String>,

    /// Force using the CPU backend.
    #[clap(long, conflicts_with = "cuda")]
    pub cpu: bool,

    /// Force using the CUDA backend (requires cuda_backend feature).
    #[clap(long, conflicts_with = "cpu")]
    pub cuda: bool,
} 