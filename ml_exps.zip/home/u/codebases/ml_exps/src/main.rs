use candle_core::{Device, Tensor, Result as CandleResult, DType, IndexOp};
use candle_nn::{linear, Module, Optimizer, VarBuilder as VB, sequential, Sequential, VarMap, AdamW, ParamsAdamW};
use rand::{SeedableRng, rngs::StdRng};
use rand::seq::SliceRandom;
use std::sync::Arc;
use std::io::{self, Write};
use candle_core::{Result, Error}; // Keep specific Result and Error
use clap::Parser;

#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
struct Args {
    /// Optional path to a training data file.
    #[clap(short, long)]
    train_data: Option<String>,

    /// Force using the CPU backend.
    #[clap(long, conflicts_with = "cuda")]
    cpu: bool,

    /// Force using the CUDA backend (requires cuda_backend feature).
    #[clap(long, conflicts_with = "cpu")]
    cuda: bool,
}

// Get default device, optionally forcing CPU or CUDA
fn get_default_device(force_cpu: bool, force_cuda: bool) -> Result<Device> {
    #[cfg(feature = "cuda_backend")]
    {
        if force_cuda {
            println!("CUDA device explicitly requested via command line.");
            // Attempt to create CUDA device, return error if it fails
            return Device::new_cuda(0).map_err(|e| {
                eprintln!("Failed to create requested CUDA device: {}. Ensure CUDA is installed and compatible.", e);
                e
            });
        }
        if force_cpu {
            println!("CPU device explicitly requested via command line.");
            return Ok(Device::Cpu);
        }

        // Default behavior when cuda_backend is enabled: Try CUDA, fallback to CPU
        println!("Checking for CUDA availability (cuda_backend feature enabled, no explicit request)...");
        if candle_core::utils::cuda_is_available() {
            println!("CUDA device available, attempting to use...");
            match Device::new_cuda(0) { // Try creating CUDA device
                Ok(dev) => return Ok(dev), // Use CUDA if successful
                Err(e) => {
                    eprintln!("Failed to create CUDA device: {}. Falling back to CPU.", e);
                    Ok(Device::Cpu) // Added fallback return
                }
            }
        } else {
            println!("CUDA not available. Falling back to CPU.");
            Ok(Device::Cpu) // Added fallback return
        }
        // Fallback should not be reached if CUDA check logic is correct, but added for safety
        // println!("Falling back to CPU device (may be MKL accelerated).");
        // Ok(Device::Cpu)
    }

    #[cfg(not(feature = "cuda_backend"))]
    {
        if force_cuda {
            // Warn if CUDA is requested but feature is not enabled
            eprintln!("Warning: --cuda flag specified, but the application was not compiled with the 'cuda_backend' feature. Using CPU.");
        }
        // Always use CPU if cuda_backend feature is not enabled
        println!("Using CPU device (cuda_backend feature not enabled).");
        Ok(Device::Cpu)
    }
}

// Define a smaller vocabulary with juapply
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const VOCAB_SIZE: usize = 32; // Reduced vocabulary size
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const EMB_DIM: usize = 1;
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const POS_DIM: usize = 1;
const NEURONS_PER_HIDDEN_LAYER: usize = 128; // Increased hidden layer size
const CONTEXT_WINDOW: usize = 64; // Reduced context window for faster testing
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const EPOCHS: usize = 100000; // Reduced epochs for quicker testing during refactor
const LR: f64 = 1e-4;
const BATCH_SIZE: usize = 32; // Added batch size for training

// Define our symbol vocabulary
const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    ' ', '.', ',', '!', '?', '-'
];

fn tokenize_char(c: char) -> Result<u32> {
    let c = c.to_ascii_lowercase();
    for (i, &symbol) in SYMBOLS.iter().enumerate() {
        if symbol == c {
            return Ok(i as u32);
        }
    }
    Err(Error::Msg(format!("Unknown character '{}'", c)))
}

fn tokenize(text: &str) -> Result<Vec<u32>> {
    let mut tokens = Vec::new();
    for c in text.chars() {
        match tokenize_char(c) {
            Ok(token) => tokens.push(token),
            Err(_) => continue, // Skip unknown characters
        }
    }
    Ok(tokens)
}

fn detokenize(token: u32) -> Result<char> {
    let idx = token as usize;
    if idx < SYMBOLS.len() {
        Ok(SYMBOLS[idx])
    } else {
        Err(Error::Msg(format!("Token {} is out of range", token)))
    }
}

// 7-LAYER STRONK MLP
pub struct TheNn {
    embedding: candle_nn::Embedding,
    pos_embedding: candle_nn::Embedding,
    hidden_layers: Sequential,
    policy_head: candle_nn::Linear,
    value_head: candle_nn::Linear,
    device: Device, // Store device
}

impl TheNn {
    pub fn new(vb: VB, vocab_size: usize, embedding_dim: usize, pos_dim: usize, hidden_dim: usize, context_window: usize) -> CandleResult<TheNn> {
        let device = vb.device().clone();
        let embedding = candle_nn::embedding(vocab_size, embedding_dim, vb.pp("embedding"))?;
        // Add positional embeddings
        let pos_embedding = candle_nn::embedding(context_window, pos_dim, vb.pp("pos_embedding"))?;

        // Ensure input dim matches embedding_dim + pos_dim if concatenating, or just embedding_dim if adding
        let input_dim = embedding_dim; // Assuming adding embeddings

        let hidden_layers = sequential::seq()
            .add(linear(input_dim, hidden_dim, vb.pp("ln1"))?)
            .add_fn(|x| x.relu())
            .add(linear(hidden_dim, hidden_dim * 2, vb.pp("ln2"))?)
            .add_fn(|x| x.relu())
            .add(linear(hidden_dim * 2, hidden_dim, vb.pp("ln3"))?);

        let policy_head = linear(hidden_dim, vocab_size, vb.pp("policy_head"))?;
        let value_head = linear(hidden_dim, 1, vb.pp("value_head"))?;

        Ok(TheNn {
            embedding,
            pos_embedding,
            hidden_layers,
            policy_head,
            value_head,
            device,
        })
    }

    pub fn forward(&self, tokens: &Tensor) -> CandleResult<(Tensor, Tensor)> {
        let (_batch_size, seq_len) = tokens.dims2()?;
        let embeddings = self.embedding.forward(tokens)?; // (B, T, EmbDim)

        // Create positional indices (0, 1, ..., T-1)
        let positions = Tensor::arange(0u32, seq_len as u32, &self.device)?.unsqueeze(0)?; // (1, T)
        let pos_embeddings = self.pos_embedding.forward(&positions)?; // (1, T, PosDim)

        // Get target shape, broadcast positional embeddings, then add
        let target_shape = embeddings.shape().clone();
        let broadcasted_pos_embeddings = pos_embeddings.broadcast_as(&target_shape)?;
        let combined_embeddings = (embeddings + broadcasted_pos_embeddings)?; // (B, T, EmbDim)

        // Process the sequence - Apply layers to the last dimension
        let hidden = self.hidden_layers.forward(&combined_embeddings)?; // (B, T, HiddenDim)

        // Take the hidden state of the *last* token for prediction
        let last_hidden_state = hidden.i((.., seq_len - 1, ..))?; // (B, HiddenDim)

        let policy_output = self.policy_head.forward(&last_hidden_state)?; // (B, VocabSize)
        let value_output = self.value_head.forward(&last_hidden_state)?; // (B, 1)
        Ok((policy_output, value_output))
    }
}

// --- Data Handling Implementation ---

/// Represents a single data item: a context window and the target token.
#[derive(Debug, Clone)]
pub struct TextItem {
    context: [u32; CONTEXT_WINDOW], // Use u32 for tokens
    target: u32,
}

/// The dataset struct holding all items.
#[derive(Debug, Clone)]
pub struct TextDataset {
    items: Vec<TextItem>,
}

impl TextDataset {
    /// Creates a new dataset from the text file.
    pub fn new(file_path: &str) -> Result<Self> {
        let data = std::fs::read_to_string(file_path)?;
        let data = data.to_lowercase();
        let tokens = tokenize(&data)?;

        println!("Dataset: {} tokens", tokens.len());

        if tokens.len() <= CONTEXT_WINDOW {
            return Err(Error::Msg(format!("Input text must be longer than {} characters", CONTEXT_WINDOW)));
        }

        let total_sequences = tokens.len() - CONTEXT_WINDOW;
        let mut items = Vec::with_capacity(total_sequences);
        // Use a seeded RNG for reproducibility if needed
        let mut rng = StdRng::seed_from_u64(42); // Example seed


        for i in 0..total_sequences {
            let start = i;
            let end = start + CONTEXT_WINDOW;
            let target_token = tokens[end];

            let sequence_u32 = &tokens[start..end];
            let mut context_array = [0u32; CONTEXT_WINDOW]; // Initialize with 0 or a pad token
            context_array.copy_from_slice(sequence_u32);

            items.push(TextItem {
                context: context_array,
                target: target_token,
            });
        }

        // Shuffle the items
        items.shuffle(&mut rng);

        Ok(Self { items })
    }

    /// Returns the number of items in the dataset
    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// Splits the dataset into training and testing sets.
    pub fn split(&self, train_ratio: f32) -> (Self, Self) {
        let n_train = (self.items.len() as f32 * train_ratio).round() as usize;
        let (train_items, test_items) = self.items.split_at(n_train);

        let train_dataset = Self { items: train_items.to_vec() };
        let test_dataset = Self { items: test_items.to_vec() };

        (train_dataset, test_dataset)
    }

    pub fn iter(&self) -> impl Iterator<Item = &TextItem> {
        self.items.iter()
    }
}

impl std::ops::Deref for TextDataset {
    type Target = Vec<TextItem>;

    fn deref(&self) -> &Self::Target {
        &self.items
    }
}

// Modify TextBatcher to work directly with Candle Tensors
pub struct TextBatcher {
    dataset: Arc<TextDataset>,
    device: Device,
    indices: Vec<usize>, // Store shuffled indices
    batch_size: usize,
    current_index: usize,
}

impl TextBatcher {
    pub fn new(dataset: Arc<TextDataset>, batch_size: usize, device: &Device) -> Self {
        let mut indices: Vec<usize> = (0..dataset.len()).collect();
        // Shuffle indices at the start of each epoch (or here for simplicity)
        let mut rng = StdRng::seed_from_u64(42); // Use same seed or a new one
        indices.shuffle(&mut rng);

        Self {
            dataset,
            device: device.clone(),
            indices,
            batch_size,
            current_index: 0,
        }
    }
}

impl Iterator for TextBatcher {
    // Return Result as tensor creation can fail
    type Item = Result<(Tensor, Tensor)>;

    fn next(&mut self) -> Option<Self::Item> {
        let start = self.current_index;
        let end = (start + self.batch_size).min(self.indices.len());

        if start >= end {
             // Reset for next epoch if needed, or just end iteration
             return None;
        }

        let batch_indices = &self.indices[start..end];
        let current_batch_size = batch_indices.len();

        let mut contexts_flat = Vec::with_capacity(current_batch_size * CONTEXT_WINDOW);
        let mut targets_vec = Vec::with_capacity(current_batch_size);

        for &idx in batch_indices {
             if let Some(item) = self.dataset.items.get(idx) {
                 contexts_flat.extend_from_slice(&item.context);
                 targets_vec.push(item.target);
             } else {
                 // Handle potential index out of bounds, though unlikely with Vec<usize>
                 return Some(Err(Error::Msg(format!("Index {} out of bounds", idx))));
             }
        }

        // Create tensors directly on the target device
        let input_tensor_res = Tensor::from_vec(
            contexts_flat,
            (current_batch_size, CONTEXT_WINDOW),
            &self.device,
        );
        let target_tensor_res = Tensor::from_vec(
             targets_vec, // Targets are u32
             current_batch_size, // Shape is [batch_size]
             &self.device,
        );


        self.current_index = end;

        // Combine results
        match (input_tensor_res, target_tensor_res) {
            (Ok(inputs), Ok(targets)) => Some(Ok((inputs, targets))),
            (Err(e), _) => Some(Err(e)),
            (_, Err(e)) => Some(Err(e)),
        }
    }
}

/// Predicts the next token based on the given context using argmax.
fn predict_next_token(model: &TheNn, context_tokens: Vec<u32>, device: &Device) -> Result<u32> {
    let context_len = context_tokens.len();
    if context_len > CONTEXT_WINDOW {
        return Err(Error::Msg(format!(
            "Input context too long ({}), max is {}",
            context_len, CONTEXT_WINDOW
        )));
    }

    // Pad the context if shorter than CONTEXT_WINDOW
    let mut context_padded = vec![0u32; CONTEXT_WINDOW]; // Pad with 0 token
    let start_index = CONTEXT_WINDOW - context_len;
    context_padded[start_index..].copy_from_slice(&context_tokens);

    // Create tensor for a single batch item
    let input_tensor = Tensor::from_vec(context_padded, (1, CONTEXT_WINDOW), device)?;

    // Get model predictions (logits for the next token)
    // forward now returns prediction for the *last* token position automatically
    let (logits_output, _value_output) = model.forward(&input_tensor)?; // Shape (1, VOCAB_SIZE)

    // Argmax to find the most likely next token ID
    let next_token_tensor = logits_output.argmax(1)?; // Argmax along the vocab dimension
    let next_token = next_token_tensor.to_scalar::<u32>()?; // Get the u32 token ID

    Ok(next_token)
}

/// Trains the model using the TextBatcher and AdamW optimizer.
pub fn train_model(model: &TheNn, varmap: &VarMap, dataset: Arc<TextDataset>, device: Device) -> Result<()> {
    // The VarMap now holds all the variables created by the VarBuilder
    let vars = varmap.all_vars(); // Get all variables from the VarMap

    // Use VarBuilder to collect all trainable variables
    let params = ParamsAdamW {
        lr: LR,
        ..Default::default() // Use default beta1, beta2, eps, weight_decay
    };
    let mut opt = AdamW::new(vars, params)?; // Pass Vec<Var>

    let mut total_loss_epoch;

    for epoch in 1..=EPOCHS {
        total_loss_epoch = 0.0;
        let mut batch_count = 0;
        // Create a new batcher for each epoch to reshuffle data
        let batcher = TextBatcher::new(dataset.clone(), BATCH_SIZE, &device);

        for batch_result in batcher {
            match batch_result {
                 Ok((inputs, targets)) => {
                     // Forward pass
                     let (logits, _value) = model.forward(&inputs)?;

                     // Compute cross-entropy loss
                     // logits: (BatchSize, VocabSize), targets: (BatchSize)
                     let loss = candle_nn::loss::cross_entropy(&logits, &targets)?;

                     // Backward pass and optimizer step
                     opt.backward_step(&loss)?;

                     total_loss_epoch += loss.to_scalar::<f32>()?; // Accumulate loss as f32
                     batch_count += 1;

                     // Optional: Print loss per batch or less frequently
                     if batch_count % 10 == 0 {
                          print!("."); // Progress indicator
                          io::stdout().flush()?;
                     }
                 }
                 Err(e) => {
                      eprintln!("Error processing batch: {}", e);
                      // Decide whether to continue or stop the epoch/training
                      continue;
                 }
            }
        }

        let avg_loss = if batch_count > 0 { total_loss_epoch / batch_count as f32 } else { 0.0 };
        println!("Epoch {}: Average Loss = {:.4}", epoch, avg_loss);

    }
    Ok(())
}

// Define a custom error type for the text processing module
#[derive(Debug)]
pub enum TextError {
    IoError(std::io::Error),
    CandleError(candle_core::Error), // Add Candle Error variant
}

impl std::fmt::Display for TextError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TextError::IoError(e) => write!(f, "IO error: {}", e),
            TextError::CandleError(e) => write!(f, "Candle error: {}", e), // Display Candle error
        }
    }
}

impl std::error::Error for TextError {}

// Implement From trait for candle_core::Error
impl From<candle_core::Error> for TextError {
    fn from(e: candle_core::Error) -> Self {
        TextError::CandleError(e)
    }
}

impl From<std::io::Error> for TextError {
    fn from(e: std::io::Error) -> Self {
        TextError::IoError(e)
    }
}

fn main() -> std::result::Result<(), TextError> { // Use our custom error type explicitly
    let args = Args::parse();

    let device = get_default_device(args.cpu, args.cuda).map_err(TextError::CandleError)?;
    println!("Using Device: {:?}", device);

    // --- Model Initialization ---
    // Use VarBuilder to initialize model parameters
    let varmap = VarMap::new(); // Create a VarMap to store variables
    let train_vb = candle_nn::VarBuilder::from_varmap(&varmap, DType::F32, &device); // For training
    // let inference_vb = candle_nn::VarBuilder::from_varmap(&varmap, DType::F32, &device); // Removed unused variable

    // Try loading training data
    let mut trained_model_opt: Option<TheNn> = None;

    if let Some(file_path) = args.train_data {
        println!("Training data file provided: {}", file_path);
        match TextDataset::new(&file_path) {
            Ok(dataset) => {
                println!("Dataset loaded successfully: {} items", dataset.len());
                // Wrap dataset in Arc before the training loop
                let dataset_arc = Arc::new(dataset);
                // Split data? Or use all for training? Let's use all for now.
                // let (train_dataset, _test_dataset) = dataset.split(0.9);

                // Initialize a new model for training
                println!("Initializing model for training...");
                let model_to_train = TheNn::new(
                    train_vb.pp("model"), // Use VarBuilder with a prefix
                    VOCAB_SIZE,
                    EMB_DIM,
                    POS_DIM,
                    NEURONS_PER_HIDDEN_LAYER,
                    CONTEXT_WINDOW
                )?;

                println!("Starting training...");
                // Pass the Arc<TextDataset>
                match train_model(&model_to_train, &varmap, dataset_arc, device.clone()) { // Pass device by value (implicit clone/move)
                    Ok(_) => {
                        println!("Training finished.");
                        trained_model_opt = Some(model_to_train); // Keep the trained model
                        // Optionally save the trained weights
                        // train_vb.save("trained_model.safetensors")?;
                        // println!("Model weights saved to trained_model.safetensors");
                    }
                    Err(e) => {
                         // Training errors are already CandleErrors or compatible
                         eprintln!("Training Error: {}", e);
                         // Fallback to using an untrained model for inference below
                    }
                }
            }
            Err(e) => {
                 eprintln!("Error loading dataset '{}': {}", file_path, e);
                 // Fallback to using an untrained model for inference below
            }
        }
    } else {
        println!("No training file provided. Using untrained model for inference.");
        // Optional: Load pre-trained weights if available
        // if std::path::Path::new("trained_model.safetensors").exists() {
        //     println!("Loading pre-trained weights from trained_model.safetensors...");
        //     inference_vb = VarBuilder::from_safetensors(&["trained_model.safetensors"], DType::F32, &device)?;
        // } else {
        //     println!("No pre-trained weights found.");
        // }
    }

    // --- Inference Model Setup ---
    // Use the trained model if available, otherwise initialize a new untrained one.
    let inference_model = match trained_model_opt {
        Some(trained_model) => {
            println!("Using the model trained in this session.");
            trained_model // Move the trained model here
        }
        None => {
            println!("Initializing a new untrained model for inference.");
            // Create a NEW VarMap and VarBuilder for a clean slate
            let inference_varmap = VarMap::new();
            let inference_vb_clean = candle_nn::VarBuilder::from_varmap(&inference_varmap, DType::F32, &device);
            // Use the new clean VarBuilder
            TheNn::new(
                inference_vb_clean.pp("model"), // Use the clean VB
                VOCAB_SIZE,
                EMB_DIM,
                POS_DIM,
                NEURONS_PER_HIDDEN_LAYER,
                CONTEXT_WINDOW
            )?
        }
    };


    // --- Interactive Prediction Loop ---
    println!("Entering interactive prediction mode.");
    println!("Type your text (or 'quit' to exit).");

    loop {
        print!("> ");
        io::stdout().flush()?;

        let mut input_text = String::new();
        io::stdin().read_line(&mut input_text)?;
        let input_text = input_text.trim();

        if input_text.eq_ignore_ascii_case("quit") {
            break;
        }

        if input_text.is_empty() {
            continue;
        }

        match tokenize(input_text) {
            Ok(tokens_u32) => {
                // Pass the cloned device for prediction
                match predict_next_token(&inference_model, tokens_u32, &device) { // Pass the original device
                    Ok(next_token) => {
                        match detokenize(next_token) {
                            Ok(next_char) => {
                                println!("Model predicts next char: '{}'", next_char);
                            }
                            Err(e) => {
                                eprintln!("Error detokenizing prediction: {}", e);
                            }
                        }
                    }
                    Err(e) => {
                        eprintln!("Error predicting next token: {}", e);
                    }
                }
            }
            Err(e) => {
                eprintln!("Error tokenizing input: {}", e);
            }
        }
    }

    println!("Exiting.");
    Ok(())
}
