use candle_core::{DType, Result, Device, Error as CandleError};
use candle_nn::{self, VarBuilder as VB, VarMap};
use std::sync::Arc;
use clap::Parser;
use std::io::{self, Write};

mod args;
mod constants;
mod data;
mod model;
mod training;
mod utils;

use crate::args::{Args, Command as AppCommand};
use crate::constants::{MAX_ANSWER_LEN, CONTEXT_WINDOW};
use crate::data::TextDataset;
use crate::model::TheNn;
use crate::training::{generate_answer, train_model};
use crate::utils::tokenize;

fn main() -> Result<()> {
    let args = Args::parse();

    match args.command {
        AppCommand::Train { cpu, train_data, .. } => { 
            println!("Starting training mode...");
            let device = if cpu { Device::Cpu } else { Device::cuda_if_available(0)? };
            println!("Using device: {:?}", &device);

            let varmap = VarMap::new();
            let vb = VB::from_varmap(&varmap, DType::F32, &device);
            let model = TheNn::new(vb, CONTEXT_WINDOW)?;

            let dataset = Arc::new(TextDataset::from_jsonl(&train_data)?); 
            println!("Dataset loaded with {} items.", dataset.items.len());

            train_model(
                &model,
                varmap.all_vars(),
                &varmap,
                dataset,
                device.clone(),
            )?;
            println!("Training finished. Model might be saved by train_model if implemented.");
        }
        AppCommand::Infer { cpu, checkpoint, .. } => { 
            println!("Starting inference mode (chat)...");
            let device = if cpu { Device::Cpu } else { Device::cuda_if_available(0)? };
            println!("Using device: {:?}", &device);

            let mut varmap = VarMap::new();
            let vb = VB::from_varmap(&varmap, DType::F32, &device);
            let model = TheNn::new(vb, CONTEXT_WINDOW)?;

            if std::path::Path::new(&checkpoint).exists() {
                println!("Loading model from checkpoint: {}...", checkpoint);
                match varmap.load(&checkpoint) {
                    Ok(_) => println!("Checkpoint loaded successfully."),
                    Err(e) => println!("Warning: Failed to load checkpoint: {}. Using fresh model.", e),
                }
            } else {
                println!("Checkpoint '{}' not found. Using fresh model.", checkpoint);
            }

            println!("\nEnter a question to get an answer (type 'exit' to quit):");
            loop {
                print!("Question: ");
                io::stdout().flush()?;

                let mut input_text = String::new();
                io::stdin().read_line(&mut input_text)?;
                let input_text = input_text.trim();

                if input_text.eq_ignore_ascii_case("exit") {
                    println!("Exiting chat mode.");
                    break;
                }
                if input_text.is_empty() {
                    continue;
                }

                let question_tokens = match tokenize(input_text) {
                    Ok(tokens) => tokens,
                    Err(e) => {
                        eprintln!("Error tokenizing question: {}", e);
                        continue;
                    }
                };
                
                match generate_answer(&model, question_tokens.clone(), MAX_ANSWER_LEN, &device) {
                    Ok(answer_tokens) => {
                        let answer_chars: candle_core::Result<Vec<String>> = answer_tokens
                            .into_iter()
                            .map(|id| {
                                char::from_u32(id)
                                    .map(|c| c.to_string())
                                    .ok_or_else(|| {
                                        CandleError::Msg(format!("Invalid token ID during detokenization: {}", id))
                                    })
                            })
                            .collect();
                        
                        match answer_chars {
                            Ok(chars) => println!("Answer: {}", chars.join("")),
                            Err(e) => eprintln!("Error detokenizing answer: {}", e),
                        }
                    },
                    Err(e) => eprintln!("Error generating answer: {}", e),
                }
            }
        }
    }

    Ok(())
}
