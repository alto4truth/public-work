use candle_core::{D, DType, Device, IndexOp, Tensor, Var};
use candle_core::{Error, Result}; // Keep specific Result and Error
use candle_nn::{
    self, Activation, AdamW, Module, Optimizer, ParamsAdamW, Sequential, VarBuilder as VB, VarMap,
    encoding::one_hot, linear, sequential,
};
use clap::Parser;
use rand::{SeedableRng, rngs::StdRng};
use rand::seq::SliceRandom;
use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};
use std::fs; // Added for directory reading

// --- Argument Parsing ---
#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
struct Args {
    /// Optional path to a training data file.
    #[clap(short, long)] // Use -t or --train-data
    train_data: Option<String>,

    /// Force using the CPU backend.
    #[clap(long, conflicts_with = "cuda")]
    cpu: bool,

    /// Force using the CUDA backend (requires cuda_backend feature).
    #[clap(long, conflicts_with = "cpu")]
    cuda: bool,
}

// Get default device, optionally forcing CPU or CUDA
fn get_default_device(_force_cpu: bool, _force_cuda: bool) -> Result<Device> {
    #[cfg(feature = "cuda_backend")]
    {
        if _force_cuda {
            println!("CUDA device explicitly requested via command line.");
            // Attempt to create CUDA device, return error if it fails
            return Device::new_cuda(0).map_err(|e| {
                eprintln!("Failed to create requested CUDA device: {}. Ensure CUDA is installed and compatible.", e);
                e
            });
        }
        if _force_cpu {
            // Use the prefixed variable here
            println!("CPU device explicitly requested via command line.");
            return Ok(Device::Cpu);
        }

        // Default behavior when cuda_backend is enabled: Try CUDA, fallback to CPU
        println!(
            "Checking for CUDA availability (cuda_backend feature enabled, no explicit request)..."
        );
        if candle_core::utils::cuda_is_available() {
            println!("CUDA device available, attempting to use...");
            match Device::new_cuda(0) {
                // Try creating CUDA device
                Ok(dev) => return Ok(dev), // Use CUDA if successful
                Err(e) => {
                    eprintln!("Failed to create CUDA device: {}. Falling back to CPU.", e);
                }
            }
        } else {
            println!("CUDA not available. Falling back to CPU.");
        }
        // Final fallback return for the cfg block
        Ok(Device::Cpu)
    }

    #[cfg(not(feature = "cuda_backend"))]
    {
        println!("Using CPU device (cuda_backend feature not enabled).");
        Ok(Device::Cpu)
    }
}

// --- Constants ---
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const VOCAB_SIZE: usize = 32; // Reverted to 32
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const POS_ENCODING_DIM: usize = 128; // Fixed Positional Encoding Dimension
const CONTEXT_WINDOW: usize = 128; // Increased from 64
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const EPOCHS: usize = 1_000_000;
const BATCH_SIZE: usize = 32;
const NEURONS_PER_HIDDEN_LAYER: usize = 128; // ADD BACK
// Use an ID outside the valid vocab range for padding
const PADDING_TOKEN_ID: u32 = VOCAB_SIZE as u32; // Set to 32

// --- CLR Parameters ---
const BASE_LR: f64 = 1e-5; // Lower bound for LR cycle
const MAX_LR: f64 = 1e-3; // Upper bound for LR cycle (Tune this!)
const STEP_SIZE_UP_ITERS: u64 = 292; // Iterations for half a cycle (e.g., 4 * est_iters_per_epoch)
const CHECKPOINT_INTERVAL_MINS: u64 = 15; // Save checkpoint every N minutes

// Define our symbol vocabulary
const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    ' ', '.', ',', '!', '?', '-' // Reverted to 32 symbols
];

fn tokenize_char(c: char) -> Result<u32> {
    let c = c.to_ascii_lowercase();
    for (i, &symbol) in SYMBOLS.iter().enumerate() {
        if symbol == c {
            return Ok(i as u32);
        }
    }
    Err(Error::Msg(format!("Unknown character '{}'", c)))
}

fn tokenize(text: &str) -> Result<Vec<u32>> {
    let mut tokens = Vec::new();
    for c in text.chars() {
        match tokenize_char(c) {
            Ok(token) => tokens.push(token),
            Err(_) => continue, // Skip unknown characters
        }
    }
    Ok(tokens)
}

fn detokenize(token: u32) -> Result<char> {
    let idx = token as usize;
    if idx < SYMBOLS.len() {
        Ok(SYMBOLS[idx])
    } else {
        Err(Error::Msg(format!("Token {} is out of range", token)))
    }
}

// --- Model Definition ---
pub struct TheNn {
    hidden_layers: Sequential,
    policy_head: candle_nn::Linear,
    span: tracing::Span,
}

impl TheNn {
    fn new(
        vb: VB,
        _context_window: usize,
    ) -> Result<Self> {
        let span = tracing::span!(tracing::Level::TRACE, "TheNn::new");
        let cloned_span = span.clone();
        let _enter = cloned_span.enter();

        // Adjust input dim: OneHot uses VOCAB_SIZE + 1 classes (incl. padding)
        let first_layer_input_dim = (VOCAB_SIZE + 1) + POS_ENCODING_DIM;
        let hidden_dim = NEURONS_PER_HIDDEN_LAYER;

        let mut hidden_layers = sequential::seq();

        // First layer
        hidden_layers = hidden_layers.add(linear(
            first_layer_input_dim,
            hidden_dim,
            vb.pp("hidden_0"),
        )?);
        hidden_layers = hidden_layers.add(Activation::Gelu);

        // Intermediate hidden layers
        for i in 1..=6 {
            hidden_layers = hidden_layers.add(linear(
                hidden_dim,
                hidden_dim,
                vb.pp(format!("hidden_{}", i)),
            )?);
            hidden_layers = hidden_layers.add(Activation::Gelu);
        }

        // Policy head predicts actual symbols, size = VOCAB_SIZE
        let policy_head = linear(hidden_dim, VOCAB_SIZE, vb.pp("policy_head"))?;

        Ok(Self {
            hidden_layers,
            policy_head,
            span,
        })
    }

    fn forward(&self, tokens: &Tensor) -> Result<Tensor> {
        let _enter = self.span.enter();
        let (b_sz, seq_len) = tokens.dims2()?;

        // Remove clamping, allow PADDING_TOKEN_ID (32)
        // let clamp_value_inf = Tensor::full(PADDING_TOKEN_ID - 1, tokens.shape(), tokens.device())?;
        // let tokens_clamped = tokens.minimum(&clamp_value_inf)?;

        // Pass original tokens to one_hot, specify num_classes = VOCAB_SIZE + 1
        let one_hot_tokens = one_hot(tokens.clone(), VOCAB_SIZE + 1, 1.0f32, 0.0f32)?;
        let position_encodings = generate_sinusoidal_positional_encodings(seq_len, POS_ENCODING_DIM, tokens.device())?;
        let position_encodings = position_encodings.broadcast_as((b_sz, seq_len, POS_ENCODING_DIM))?;

        // Adjust expected dimension for concatenation
        // let expected_cat_dim = (VOCAB_SIZE + 1) + POS_ENCODING_DIM;
        let combined_input = Tensor::cat(
            &[
                one_hot_tokens.to_dtype(DType::F32)?,
                position_encodings.to_dtype(DType::F32)?,
            ],
            D::Minus1, // Shape [batch_size, seq_len, VOCAB_SIZE + 1 + POS_ENCODING_DIM]
        )?;
        let combined_input = combined_input.contiguous()?;

        // Hidden layers process the combined input
        let hidden = self.hidden_layers.forward(&combined_input)?;

        let last_hidden_state = hidden.i((.., seq_len - 1, ..))?;
        let last_hidden_state_contiguous = last_hidden_state.contiguous()?;

        // Policy head output shape [batch_size, VOCAB_SIZE]
        let policy_output = self
            .policy_head
            .forward(&last_hidden_state_contiguous)?;

        Ok(policy_output)
    }
}

// --- Data Handling Implementation ---

/// Represents a single data item: a context window and the target token.
#[derive(Debug, Clone)]
pub struct TextItem {
    context: [u32; CONTEXT_WINDOW], // Use u32 for tokens
    target: u32,
}

/// The dataset struct holding all items.
#[derive(Debug, Clone)]
pub struct TextDataset {
    items: Vec<TextItem>,
}

impl TextDataset {
    /// Creates a new dataset from the text file.
    pub fn new(file_path: &str) -> Result<Self> {
        let data = std::fs::read_to_string(file_path)?;
        let data = data.to_lowercase();
        let tokens = tokenize(&data)?;

        println!("Dataset: {} tokens", tokens.len());

        // Need at least one token to predict
        if tokens.is_empty() {
            return Err(Error::Msg("Input text cannot be empty".to_string()));
        }

        let total_sequences = tokens.len(); // Generate sequence for each token
        let mut items = Vec::with_capacity(total_sequences);
        let mut rng = rand::rng();

        for i in 0..total_sequences {
            // Target is the token at index i
            let target_token = tokens[i];

            // Context is the preceding CONTEXT_WINDOW tokens
            let context_start = if i < CONTEXT_WINDOW { 0 } else { i - CONTEXT_WINDOW };
            let actual_context = &tokens[context_start..i];

            // Create context array and prepend padding if needed
            let mut context_array = [PADDING_TOKEN_ID; CONTEXT_WINDOW];
            let context_len = actual_context.len();
            let pad_len = CONTEXT_WINDOW - context_len;
            context_array[pad_len..].copy_from_slice(actual_context);

            items.push(TextItem {
                context: context_array,
                target: target_token,
            });
        }

        // Shuffle the items using rand::rng()
        items.shuffle(&mut rng);

        Ok(Self { items })
    }

    /// Returns the number of items in the dataset
    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// Returns true if the dataset contains no items.
    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    /// Splits the dataset into training and testing sets.
    pub fn split(&self, train_ratio: f32) -> (Self, Self) {
        let n_train = (self.items.len() as f32 * train_ratio).round() as usize;
        let (train_items, test_items) = self.items.split_at(n_train);

        let train_dataset = Self {
            items: train_items.to_vec(),
        };
        let test_dataset = Self {
            items: test_items.to_vec(),
        };

        (train_dataset, test_dataset)
    }

    pub fn iter(&self) -> impl Iterator<Item = &TextItem> {
        self.items.iter()
    }
}

impl std::ops::Deref for TextDataset {
    type Target = Vec<TextItem>;

    fn deref(&self) -> &Self::Target {
        &self.items
    }
}

// Modify TextBatcher to work directly with Candle Tensors
pub struct TextBatcher {
    dataset: Arc<TextDataset>,
    device: Device,
    indices: Vec<usize>, // Store shuffled indices
    batch_size: usize,
    current_index: usize,
}

impl TextBatcher {
    // Add epoch parameter for unique shuffling seed per epoch
    pub fn new(
        dataset: Arc<TextDataset>,
        batch_size: usize,
        device: &Device,
        epoch: usize,
    ) -> Self {
        let mut indices: Vec<usize> = (0..dataset.len()).collect();
        // Shuffle indices deterministically based on epoch
        let mut rng = StdRng::seed_from_u64(42 + epoch as u64); // Use StdRng seeded by epoch
        indices.shuffle(&mut rng);

        Self {
            dataset,
            device: device.clone(),
            indices,
            batch_size,
            current_index: 0,
        }
    }
}

impl Iterator for TextBatcher {
    // Return Result as tensor creation can fail
    type Item = Result<(Tensor, Tensor)>;

    fn next(&mut self) -> Option<Self::Item> {
        let start = self.current_index;
        let end = (start + self.batch_size).min(self.indices.len());

        if start >= end {
            // Reset for next epoch if needed, or just end iteration
            return None;
        }

        let batch_indices = &self.indices[start..end];
        let current_batch_size = batch_indices.len();

        let mut contexts_flat = Vec::with_capacity(current_batch_size * CONTEXT_WINDOW);
        let mut targets_vec = Vec::with_capacity(current_batch_size);

        for &idx in batch_indices {
            if let Some(item) = self.dataset.items.get(idx) {
                contexts_flat.extend_from_slice(&item.context);
                targets_vec.push(item.target);
            } else {
                // Handle potential index out of bounds, though unlikely with Vec<usize>
                return Some(Err(Error::Msg(format!("Index {} out of bounds", idx))));
            }
        }

        // Create tensors directly on the target device
        let input_tensor_res = Tensor::from_vec(
            contexts_flat,
            (current_batch_size, CONTEXT_WINDOW),
            &self.device,
        );
        let target_tensor_res = Tensor::from_vec(
            targets_vec,        // Targets are u32
            current_batch_size, // Shape is [batch_size]
            &self.device,
        );

        self.current_index = end;

        // Combine results
        match (input_tensor_res, target_tensor_res) {
            (Ok(inputs), Ok(targets)) => Some(Ok((inputs, targets))),
            (Err(e), _) => Some(Err(e)),
            (_, Err(e)) => Some(Err(e)),
        }
    }
}

/// Predicts the next token based on the given context using argmax.
fn predict_next_token(model: &TheNn, context_tokens: Vec<u32>, device: &Device) -> Result<u32> {
    let context_len = context_tokens.len();
    if context_len > CONTEXT_WINDOW {
        return Err(Error::Msg(format!(
            "Input context too long ({}), max is {}",
            context_len, CONTEXT_WINDOW
        )));
    }

    // Pad with the ID representing padding (outside vocab range)
    let mut context_padded = vec![PADDING_TOKEN_ID; CONTEXT_WINDOW];
    let start_index = CONTEXT_WINDOW - context_len;
    context_padded[start_index..].copy_from_slice(&context_tokens);

    let input_tensor = Tensor::from_vec(context_padded, (1, CONTEXT_WINDOW), device)?;

    let logits_output = model.forward(&input_tensor)?; // Shape (1, VOCAB_SIZE)

    let next_token_tensor = logits_output.argmax(1)?;
    let next_token = next_token_tensor.to_scalar::<u32>()?;

    Ok(next_token)
}

/// Trains the model using the TextBatcher and AdamW optimizer.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap,
    dataset: Arc<TextDataset>,
    device: Device,
) -> Result<()> {
    // TODO: implement recurrent saving of model (checkpoints) every N minutes

    // Initialize optimizer params with BASE_LR (actual LR set each step)
    let params = ParamsAdamW {
        lr: BASE_LR,
        ..Default::default()
    };
    let mut opt = AdamW::new(vars, params)?;

    let report_interval = Duration::from_secs(10); // Report progress interval
    let checkpoint_interval = Duration::from_secs(CHECKPOINT_INTERVAL_MINS * 60); // Checkpoint interval

    let mut last_report_time = Instant::now();
    let mut last_checkpoint_time = Instant::now();
    let training_start_time = Instant::now();

    let mut interval_loss = 0.0f32;
    let mut interval_batches = 0u32;
    let mut total_batches_processed: u64 = 0;

    println!(
        "Starting training with CLR: Base LR={:.1e}, Max LR={:.1e}, Step Size Up={}",
        BASE_LR, MAX_LR, STEP_SIZE_UP_ITERS
    );

    for epoch in 1..=EPOCHS {
        let mut batch_count = 0;
        // Pass epoch to TextBatcher::new
        let batcher = TextBatcher::new(dataset.clone(), BATCH_SIZE, &device, epoch);

        for batch_result in batcher {
            total_batches_processed += 1;
            let now = Instant::now(); // Get current time for reports/checkpoints

            match batch_result {
                Ok((inputs, targets)) => {
                    // --- Calculate CLR ---
                    let cycle = (total_batches_processed as f64
                        / (2.0 * STEP_SIZE_UP_ITERS as f64))
                        .floor();
                    let x = (total_batches_processed as f64 / STEP_SIZE_UP_ITERS as f64
                        - 2.0 * cycle)
                        .abs();
                    let current_lr = BASE_LR + (MAX_LR - BASE_LR) * (1.0 - x).max(0.0);
                    opt.set_learning_rate(current_lr);
                    // ---------------------

                    // Update call site: forward now returns only policy logits
                    let logits = match model.forward(&inputs) {
                        Ok(output) => output,
                        Err(e) => {
                            eprintln!(
                                "Epoch {}, Batch {}: Forward pass error: {}",
                                epoch,
                                batch_count + 1,
                                e
                            );
                            continue; // Skip this batch
                        }
                    };

                    // --- Manual Masked Cross-Entropy Loss ---
                    // LogSoftmax
                    let log_probs = candle_nn::ops::log_softmax(&logits, D::Minus1)?;
                    
                    // Clamp padding indices before gathering to avoid out-of-bounds
                    // Target shape: [batch_size]
                    // Clamp PADDING_TOKEN_ID (32) to VOCAB_SIZE - 1 (31)
                    let clamp_value = Tensor::full(PADDING_TOKEN_ID - 1, targets.shape(), &device)?;
                    let targets_clamped = targets.minimum(&clamp_value)?;
                    // Need targets expanded for gather: [batch_size, 1]
                    let targets_expanded_clamped = targets_clamped.unsqueeze(D::Minus1)?;

                    // Gather log probabilities of target tokens
                    let gathered_log_probs = log_probs.gather(&targets_expanded_clamped, D::Minus1)?.squeeze(D::Minus1)?;

                    // Create mask: 1.0 where target is NOT padding, 0.0 where it is
                    let mask = targets.ne(PADDING_TOKEN_ID)?.to_dtype(DType::F32)?;

                    // Apply mask (element-wise multiplication)
                    let masked_neg_log_probs = (gathered_log_probs * &mask)?.neg()?;

                    // Calculate sum of masked losses
                    let sum_loss = masked_neg_log_probs.sum_all()?;

                    // Calculate number of non-padded tokens
                    let num_tokens = mask.sum_all()?.to_scalar::<f32>()?;

                    // Average loss over non-padded tokens (handle case of zero tokens)
                    let loss = if num_tokens > 0.0 {
                        sum_loss.div(&Tensor::new(num_tokens, &device)?)?
                    } else {
                        // Avoid division by zero if batch has only padding (shouldn't happen with current dataset)
                        Tensor::zeros((), DType::F32, &device)?
                    };
                    // --- End Masked Loss ---

                    let loss_f32 = match loss.to_scalar::<f32>() {
                        Ok(val) => val,
                        Err(e) => {
                            eprintln!(
                                "Epoch {}, Batch {}: Loss to_scalar error: {}",
                                epoch,
                                batch_count + 1,
                                e
                            );
                            continue; // Skip this batch
                        }
                    };

                    if let Err(e) = opt.backward_step(&loss) {
                        eprintln!(
                            "Epoch {}, Batch {}: Backward step error: {}",
                            epoch,
                            batch_count + 1,
                            e
                        );
                        // Decide whether to continue the epoch or return the error
                        // For now, let's skip the batch
                        continue;
                    }

                    interval_loss += loss_f32;
                    batch_count += 1;
                    interval_batches += 1;

                    // --- Time-based progress reporting ---
                    if now.duration_since(last_report_time) >= report_interval {
                        let elapsed_interval = now.duration_since(last_report_time).as_secs_f32();
                        let avg_interval_loss = if interval_batches > 0 {
                            interval_loss / interval_batches as f32
                        } else {
                            0.0
                        };
                        let total_elapsed_in_if = training_start_time.elapsed().as_secs_f32(); // Keep for printing
                        println!(
                            "Epoch: {}, Batch: {}, Total Time: {:.1}s, Interval Time: {:.1}s, Batches/sec: {:.1}, Avg Interval Loss: {:.4}, LR: {:.1e}",
                            epoch,
                            batch_count,
                            total_elapsed_in_if, // Use the value calculated inside
                            elapsed_interval,
                            interval_batches as f32 / elapsed_interval,
                            avg_interval_loss,
                            current_lr // Also report current LR
                        );
                        // Reset interval tracking
                        interval_loss = 0.0;
                        interval_batches = 0;
                        last_report_time = now;
                        io::stdout().flush()?;
                    }

                    // Define total_elapsed here so it's available for checkpointing
                    let total_elapsed = training_start_time.elapsed().as_secs_f32();

                    // --- Periodic checkpoint saving ---
                    if now.duration_since(last_checkpoint_time) >= checkpoint_interval {
                        // Use the passed-in varmap for saving
                        match varmap.save(format!("model_epoch_{}.safetensors", epoch)) {
                            Ok(()) => {
                                println!(
                                    "Checkpoint saved at {} minutes",
                                    (total_elapsed / 60.0).round()
                                );
                                last_checkpoint_time = now;
                            }
                            Err(e) => {
                                eprintln!("Failed to save checkpoint: {}", e);
                            }
                        }
                    }
                }
                Err(e) => {
                    eprintln!(
                        "Epoch {}, Batch {}: Batch error: {}",
                        epoch,
                        batch_count + 1,
                        e
                    );
                    continue;
                }
            }
        }
    }

    Ok(())
}

// --- Positional Encoding Implementation ---
fn generate_sinusoidal_positional_encodings(
    seq_len: usize,
    dim: usize,
    device: &Device,
) -> Result<Tensor> {
    if dim % 2 != 0 {
        return Err(Error::Msg(
            "Positional encoding dimension must be even".to_string(),
        ));
    }
    let mut pos_enc = vec![0.0f32; seq_len * dim];

    for pos in 0..seq_len {
        for i in 0..(dim / 2) {
            let div_term = (10000.0f32).powf((2 * i) as f32 / dim as f32);
            let angle = pos as f32 / div_term;

            let sin_idx = pos * dim + 2 * i;
            let cos_idx = pos * dim + 2 * i + 1;

            if sin_idx < pos_enc.len() {
                pos_enc[sin_idx] = angle.sin();
            }
            if cos_idx < pos_enc.len() {
                pos_enc[cos_idx] = angle.cos();
            }
        }
    }

    Tensor::from_vec(pos_enc, (1, seq_len, dim), device)
}

// --- Main Function ---
#[derive(Debug)]
pub enum TextError {
    IoError(std::io::Error),
    CandleError(candle_core::Error),
    DataError(String),
}

impl std::fmt::Display for TextError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TextError::IoError(e) => write!(f, "IO error: {}", e),
            TextError::CandleError(e) => write!(f, "Candle error: {}", e),
            TextError::DataError(e) => write!(f, "Data error: {}", e),
        }
    }
}

impl From<candle_core::Error> for TextError {
    fn from(e: candle_core::Error) -> Self {
        TextError::CandleError(e)
    }
}

impl From<std::io::Error> for TextError {
    fn from(e: std::io::Error) -> Self {
        TextError::IoError(e)
    }
}

fn main() -> std::result::Result<(), TextError> {
    let args = Args::parse();

    // Get device
    let device = get_default_device(args.cpu, args.cuda)?;
    println!("Using device: {:?}", device);

    // Load dataset
    let file_path = args
        .train_data
        .ok_or_else(|| TextError::DataError("No training data file provided".to_string()))?;
    let dataset = match TextDataset::new(&file_path) {
        // Pass reference
        Ok(d) => Arc::new(d),
        Err(e) => {
            return Err(TextError::DataError(format!(
                "Failed to load dataset: {}",
                e
            )));
        }
    };

    // Create VarMap first (make it mutable for loading checkpoints)
    let mut varmap = VarMap::new();
    let vb = VB::from_varmap(&varmap, DType::F32, &device);

    // Create model instance (initially empty or with random weights)
    let model = match TheNn::new(vb, CONTEXT_WINDOW) {
        Ok(m) => m,
        Err(e) => return Err(TextError::CandleError(e)),
    };

    // --- Training ---
    println!("Starting training...");
    // Train model using the existing varmap and extracted variables
    let vars = varmap.all_vars(); // Get variables AFTER model creation
    let training_result = train_model(&model, vars, &varmap, dataset, device.clone()); // Pass Vec<Var> and &VarMap

    match training_result {
        Ok(()) => println!("Training completed successfully"),
        Err(e) => {
            eprintln!(
                "Training failed: {}. Attempting inference with potentially untrained model.",
                e
            );
            // Continue to inference even if training failed, model might have loaded weights if run previously
        }
    }

    // --- Inference ---
    // Attempt to load the latest checkpoint *after* training attempt

    // Find the latest epoch checkpoint file by modification time
    let latest_checkpoint_path = match fs::read_dir(".") { // Read current directory
        Ok(entries) => {
            entries.filter_map(|entry_res| {
                entry_res.ok().and_then(|entry| {
                    let path = entry.path();
                    if path.is_file() {
                        path.file_name()
                            .and_then(|name| name.to_str())
                            .filter(|name_str| {
                                // Check filename pattern
                                name_str.starts_with("model_epoch_") && name_str.ends_with(".safetensors")
                            })
                            .and_then(|_| {
                                // Get modification time
                                fs::metadata(&path).ok()?.modified().ok()
                            })
                            .map(|mod_time| (path.clone(), mod_time)) // Pair path with mod time
                    } else {
                        None
                    }
                })
            })
            .max_by_key(|&(_, mod_time)| mod_time) // Find the entry with the latest time
            .map(|(path, _)| path) // Extract the path
        },
        Err(e) => {
            eprintln!("Warning: Could not read directory to find checkpoints: {}. Inference will use current model state.", e);
            None
        }
    };

    // Load the checkpoint with the latest modification time
    if let Some(checkpoint_path_buf) = latest_checkpoint_path {
        if let Some(checkpoint_path) = checkpoint_path_buf.to_str() {
            println!("Loading weights from latest checkpoint: {}", checkpoint_path);
            match varmap.load(checkpoint_path) { // Use the found path directly
                Ok(()) => println!("Weights loaded successfully."),
                Err(e) => eprintln!(
                    "Failed to load weights from checkpoint {}: {}. Using current model state.",
                    checkpoint_path, e
                ),
            }
        } else {
            eprintln!("Warning: Found latest checkpoint path but it's not valid UTF-8. Using current model state.");
        }
    } else {
        println!("No epoch checkpoints found. Using initial/current model state for inference.");
    }

    println!("\nEnter text to get predictions (type 'exit' to quit):");
    loop {
        print!("> ");
        io::stdout().flush()?;

        let mut input_text = String::new();
        io::stdin().read_line(&mut input_text)?;

        let input_text = input_text.trim();
        if input_text.eq_ignore_ascii_case("exit") {
            break;
        }

        let tokens = match tokenize(input_text) {
            Ok(t) => t,
            Err(e) => {
                eprintln!("Tokenization error: {}", e);
                continue;
            }
        };

        let inference_model = &model; // Use reference to the existing model

        let next_token = match predict_next_token(inference_model, tokens, &device) {
            // Pass the reference
            Ok(t) => t,
            Err(e) => {
                eprintln!("Prediction error: {}", e);
                continue;
            }
        };

        let char = match detokenize(next_token) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("Detokenization error: {}", e);
                continue;
            }
        };

        println!("Next token: {} ({})", char, next_token);
    }

    Ok(())
}
