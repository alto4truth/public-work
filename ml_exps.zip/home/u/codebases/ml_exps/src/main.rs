use candle_core::{D, DType, Device, Error, IndexOp, Result, Tensor};
use candle_nn::{
    self, linear, optim::{AdamW, ParamsAdamW}, VarBuilder as VB, VarMap, Module, Activation
};
use candle_nn::encoding;
use clap::Parser;
use rand::prelude::*;
use rand::rngs::StdRng;
use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};
use candle_core::Var;
use training::{train_model, generate_answer};

// Declare modules
mod error;
mod constants;
mod args;
mod device;
mod tokenization;
mod utils;
mod model;
mod data;
mod training;

// Import items
use error::TextError;
use constants::CONTEXT_WINDOW; // Only import what's needed
use args::Args;
use device::get_default_device;
use tokenization::{tokenize, detokenize};
use model::TheNn;
use data::TextDataset;

// --- Argument Parsing ---


// Get default device, optionally forcing CPU or CUDA



// --- Constants ---



// Define our symbol vocabulary
// Derive VOCAB_SIZE from SYMBOLS

// Use an ID outside the valid vocab range for padding



// --- Model Definition ---


// --- Data Handling Implementation ---










// --- Positional Encoding Implementation ---


// --- Main Function ---
fn main() -> std::result::Result<(), TextError> {
    let args = Args::parse();

    // Get device
    let device = get_default_device(args.cpu, args.cuda)?;
    println!("Using device: {:?}", device);

    // Load dataset
    let file_path = args
        .train_data
        .ok_or_else(|| TextError::DataError("No training data file provided (expecting Q-A format)".to_string()))?;
    let dataset = TextDataset::new(&file_path)
        .map_err(|e| TextError::DataError(format!("Failed to load Q-A dataset: {}", e)))
        .map(Arc::new)?;
    println!("Dataset loaded.");

    // Create VarMap and VarBuilder
    let mut varmap = VarMap::new();
    let vb = VB::from_varmap(&varmap, DType::F32, &device);

    // Create model instance
    let model = TheNn::new(vb, CONTEXT_WINDOW)?; // Pass context window from constants

    // --- Training --- (Uses functions from training module)
    println!("Starting Q-A training...");
    let vars = varmap.all_vars(); // Get variables AFTER model creation
    match train_model(&model, vars, &varmap, dataset.clone(), device.clone()) { // Pass cloned device if needed
        Ok(()) => println!("Training completed successfully"),
        Err(e) => {
            eprintln!(
                "Training failed: {}. Attempting inference with potentially untrained model.",
                e
            );
        }
    }

    // --- Inference --- (Uses functions from training and tokenization modules)
    let checkpoint_path = "model_checkpoint.safetensors";
    if std::path::Path::new(checkpoint_path).exists() {
        println!("Loading weights from checkpoint: {}", checkpoint_path);
        // Use the existing mutable varmap to load weights into it
        match varmap.load(checkpoint_path) {
            Ok(()) => println!("Weights loaded successfully."),
            Err(e) => eprintln!(
                "Failed to load weights from checkpoint {}: {}. Using current model state.",
                checkpoint_path, e
            ),
        }
    } else {
        println!(
            "Checkpoint file '{}' not found. Using model state after training (if any).",
            checkpoint_path
        );
    }

    // --- Q-A Inference Loop --- 
    println!("\nEnter a question to get an answer (type 'exit' to quit):");
    loop {
        print!("Question: ");
        io::stdout().flush()?;

        let mut input_text = String::new();
        io::stdin().read_line(&mut input_text)?;
        let input_text = input_text.trim();

        if input_text.eq_ignore_ascii_case("exit") {
            break;
        }
        if input_text.is_empty() {
            continue;
        }

        // Tokenize the input question
        let question_tokens = match tokenize(input_text) {
             Ok(tokens) => tokens,
             Err(e) => {
                 eprintln!("Tokenization error: {}", e);
                 continue;
             }
        };

        // Generate answer tokens using the new function
        // Define a max length for the generated answer
        let max_answer_len = 100; // Or get from args
        let answer_tokens = match generate_answer(&model, question_tokens, max_answer_len, &device) {
            Ok(tokens) => tokens,
            Err(e) => {
                eprintln!("Prediction error: {}", e);
                continue;
            }
        };

        // Detokenize the generated answer tokens
        // Remember detokenize now returns Result<String>
        let answer_chars: Result<Vec<String>> = answer_tokens.into_iter().map(detokenize).collect();
        match answer_chars {
            Ok(chars) => {
                let answer_string = chars.join("");
                 println!("Answer: {}", answer_string);
            }
            Err(e) => {
                eprintln!("Detokenization error: {}", e);
            }
        }
    }

    Ok(())
}
