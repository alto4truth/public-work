use candle_core::{D, DType, Device, Error, IndexOp, Result, Tensor};
use candle_nn::{
    self, linear, optim::{AdamW, ParamsAdamW}, VarBuilder as VB, VarMap, Module, Activation
};
use candle_nn::encoding;
use clap::Parser;
use rand::prelude::*;
use rand::rngs::StdRng;
use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};
use candle_core::Var;
use training::{train_model, predict_next_token};

// Declare modules
mod error;
mod constants;
mod args;
mod device;
mod tokenization;
mod utils;
mod model;
mod data;
mod training;

// Import items
use error::TextError;
use constants::CONTEXT_WINDOW; // Only import what's needed
use args::Args;
use device::get_default_device;
use tokenization::{tokenize, detokenize};
use model::TheNn;
use data::TextDataset;

// --- Argument Parsing ---


// Get default device, optionally forcing CPU or CUDA
/* REMOVE THIS FUNCTION BODY */


// --- Constants ---
/* REMOVE THIS CONSTANTS BLOCK */


// Define our symbol vocabulary
const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    ' ', '.', ',', '!', '?', '-' // Reverted to 32 symbols
];

// Derive VOCAB_SIZE from SYMBOLS
const VOCAB_SIZE: usize = SYMBOLS.len(); // Now 32

// Use an ID outside the valid vocab range for padding
const PADDING_TOKEN_ID: u32 = VOCAB_SIZE as u32; // Use VOCAB_SIZE as the padding token ID (now 32)
const NUM_HIDDEN_LAYERS: usize = 7; // Added constant for number of hidden layers
const HIDDEN_DIM: usize = 128; // Define hidden dimension
const CHECKPOINT_INTERVAL_MINS: u64 = 15; // Save checkpoint every N minutes

/* REMOVE THIS TOKENIZATION BLOCK */


// --- Model Definition ---
/*
pub struct TheNn {
// ... existing code ...
}
*/

// --- Data Handling Implementation ---
/*
/// Represents a single data item: a context window and the target token.
// ... existing code ...
}
*/

/*
/// Predicts the next token based on the given context using argmax.
fn predict_next_token(model: &TheNn, context_tokens: Vec<u32>, device: &Device) -> Result<u32> {
    // ... function body ...
}
*/

/*
/// Trains the model using the TextBatcher and AdamW optimizer.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap,
    dataset: Arc<TextDataset>,
    device: Device,
) -> Result<()> {
   // ... function body ...
}
*/

// --- Positional Encoding Implementation ---
/*
fn generate_sinusoidal_positional_encodings(
// ... existing code ...
}
*/

// --- Main Function ---
fn main() -> std::result::Result<(), TextError> {
    let args = Args::parse();

    // Get device
    let device = get_default_device(args.cpu, args.cuda)?;
    println!("Using device: {:?}", device);

    // Load dataset
    let file_path = args
        .train_data
        .ok_or_else(|| TextError::DataError("No training data file provided".to_string()))?;
    let dataset = TextDataset::new(&file_path)
        .map_err(|e| TextError::DataError(format!("Failed to load dataset: {}", e)))
        .map(Arc::new)?;

    // Create VarMap and VarBuilder
    let mut varmap = VarMap::new();
    let vb = VB::from_varmap(&varmap, DType::F32, &device);

    // Create model instance
    let model = TheNn::new(vb, CONTEXT_WINDOW)?; // Pass context window from constants

    // --- Training --- (Uses functions from training module)
    println!("Starting training...");
    let vars = varmap.all_vars(); // Get variables AFTER model creation
    match train_model(&model, vars, &varmap, dataset.clone(), device.clone()) { // Pass cloned device if needed
        Ok(()) => println!("Training completed successfully"),
        Err(e) => {
            eprintln!(
                "Training failed: {}. Attempting inference with potentially untrained model.",
                e
            );
        }
    }

    // --- Inference --- (Uses functions from training and tokenization modules)
    let checkpoint_path = "model_checkpoint.safetensors";
    if std::path::Path::new(checkpoint_path).exists() {
        println!("Loading weights from checkpoint: {}", checkpoint_path);
        // Use the existing mutable varmap to load weights into it
        match varmap.load(checkpoint_path) {
            Ok(()) => println!("Weights loaded successfully."),
            Err(e) => eprintln!(
                "Failed to load weights from checkpoint {}: {}. Using current model state.",
                checkpoint_path, e
            ),
        }
    } else {
        println!(
            "Checkpoint file '{}' not found. Using initial/current model state for inference.",
            checkpoint_path
        );
    }

    println!("\nEnter text to get predictions (type 'exit' to quit):");
    loop {
        print!("> ");
        io::stdout().flush()?;

        let mut input_text = String::new();
        io::stdin().read_line(&mut input_text)?;

        let input_text = input_text.trim();
        if input_text.eq_ignore_ascii_case("exit") {
            break;
        }

        let tokens = tokenize(input_text)?;
        
        // Predict next token using the function from the training module
        let next_token = match predict_next_token(&model, tokens, &device) { 
            Ok(t) => t,
            Err(e) => {
                eprintln!("Prediction error: {}", e);
                continue;
            }
        };

        // Detokenize using the function from the tokenization module
        let char = match detokenize(next_token) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("Detokenization error: {}", e);
                continue;
            }
        };

        println!("Next token: {} ({})", char, next_token);
    }

    Ok(())
}
