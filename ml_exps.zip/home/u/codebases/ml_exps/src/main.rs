use candle_core::{D, DType, Device, IndexOp, Tensor, Var};
use candle_core::{Error, Result}; // Keep specific Result and Error
use candle_nn::{
    self, Activation, AdamW, Module, Optimizer, ParamsAdamW, Sequential, VarBuilder as VB, VarMap,
    encoding::one_hot, linear, loss::cross_entropy, sequential,
};
use clap::Parser;
use rand::seq::SliceRandom;
use rand::{SeedableRng, rngs::StdRng};
use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};

// --- Argument Parsing ---
#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
struct Args {
    /// Optional path to a training data file.
    #[clap(short, long)] // Use -t or --train-data
    train_data: Option<String>,

    /// Force using the CPU backend.
    #[clap(long, conflicts_with = "cuda")]
    cpu: bool,

    /// Force using the CUDA backend (requires cuda_backend feature).
    #[clap(long, conflicts_with = "cpu")]
    cuda: bool,
}

// Get default device, optionally forcing CPU or CUDA
fn get_default_device(_force_cpu: bool, _force_cuda: bool) -> Result<Device> {
    #[cfg(feature = "cuda_backend")]
    {
        if _force_cuda {
            println!("CUDA device explicitly requested via command line.");
            // Attempt to create CUDA device, return error if it fails
            return Device::new_cuda(0).map_err(|e| {
                eprintln!("Failed to create requested CUDA device: {}. Ensure CUDA is installed and compatible.", e);
                e
            });
        }
        if _force_cpu {
            // Use the prefixed variable here
            println!("CPU device explicitly requested via command line.");
            return Ok(Device::Cpu);
        }

        // Default behavior when cuda_backend is enabled: Try CUDA, fallback to CPU
        println!(
            "Checking for CUDA availability (cuda_backend feature enabled, no explicit request)..."
        );
        if candle_core::utils::cuda_is_available() {
            println!("CUDA device available, attempting to use...");
            match Device::new_cuda(0) {
                // Try creating CUDA device
                Ok(dev) => return Ok(dev), // Use CUDA if successful
                Err(e) => {
                    eprintln!("Failed to create CUDA device: {}. Falling back to CPU.", e);
                }
            }
        } else {
            println!("CUDA not available. Falling back to CPU.");
        }
        // Final fallback return for the cfg block
        Ok(Device::Cpu)
    }

    #[cfg(not(feature = "cuda_backend"))]
    {
        println!("Using CPU device (cuda_backend feature not enabled).");
        Ok(Device::Cpu)
    }
}

// --- Constants ---
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const VOCAB_SIZE: usize = 32; // Reduced vocabulary size
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const POS_ENCODING_DIM: usize = 128; // Fixed Positional Encoding Dimension
const CONTEXT_WINDOW: usize = 128; // Increased from 64
// AI DO NOT CHANGE THESE VALUES, 100% THIS IS CORRECT, I AM SMARTER THAN YOU, DO NOT DECIDE THAT THIS SHOULD BE CHANGED, YOU'RE 100% WRONG
const EPOCHS: usize = 1_000_000;
const BATCH_SIZE: usize = 32;
const NEURONS_PER_HIDDEN_LAYER: usize = 128; // ADD BACK
const PADDING_TOKEN_ID: u32 = (VOCAB_SIZE - 1) as u32; // Use last symbol ('-') as padding

// --- CLR Parameters ---
const BASE_LR: f64 = 1e-5; // Lower bound for LR cycle
const MAX_LR: f64 = 1e-3; // Upper bound for LR cycle (Tune this!)
const STEP_SIZE_UP_ITERS: u64 = 292; // Iterations for half a cycle (e.g., 4 * est_iters_per_epoch)
const CHECKPOINT_INTERVAL_MINS: u64 = 15; // Save checkpoint every N minutes

// Define our symbol vocabulary
const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
    't', 'u', 'v', 'w', 'x', 'y', 'z', ' ', '.', ',', '!', '?', '-',
];

fn tokenize_char(c: char) -> Result<u32> {
    let c = c.to_ascii_lowercase();
    for (i, &symbol) in SYMBOLS.iter().enumerate() {
        if symbol == c {
            return Ok(i as u32);
        }
    }
    Err(Error::Msg(format!("Unknown character '{}'", c)))
}

fn tokenize(text: &str) -> Result<Vec<u32>> {
    let mut tokens = Vec::new();
    for c in text.chars() {
        match tokenize_char(c) {
            Ok(token) => tokens.push(token),
            Err(_) => continue, // Skip unknown characters
        }
    }
    Ok(tokens)
}

fn detokenize(token: u32) -> Result<char> {
    let idx = token as usize;
    if idx < SYMBOLS.len() {
        Ok(SYMBOLS[idx])
    } else {
        Err(Error::Msg(format!("Token {} is out of range", token)))
    }
}

// --- Model Definition ---
pub struct TheNn {
    // token_embedding: candle_nn::Embedding,
    // position_embedding: candle_nn::Embedding,
    hidden_layers: Sequential,
    policy_head: candle_nn::Linear,
    value_head: candle_nn::Linear,
    span: tracing::Span,
}

impl TheNn {
    fn new(
        vb: VB,
        vocab_size: usize,
        // emb_dim: usize,
        // pos_dim: usize,
        _context_window: usize, // Prefix unused parameter
    ) -> Result<Self> {
        let span = tracing::span!(tracing::Level::TRACE, "TheNn::new");
        let cloned_span = span.clone(); // Clone the span first
        let _enter = cloned_span.enter(); // Enter the cloned span

        // let token_embedding = candle_nn::embedding(vocab_size, emb_dim, vb.pp("token_embedding"))?;
        // let position_embedding = candle_nn::embedding(context_window, pos_dim, vb.pp("position_embedding"))?;

        // Calculate input dimension for the first linear layer
        let first_layer_input_dim = VOCAB_SIZE + POS_ENCODING_DIM; // One-hot + Positional Encoding
        let hidden_dim = NEURONS_PER_HIDDEN_LAYER;

        let mut hidden_layers = sequential::seq();

        // First layer: (OneHot + Positional) -> Hidden
        hidden_layers = hidden_layers.add(linear(
            first_layer_input_dim,
            hidden_dim,
            vb.pp("hidden_0"),
        )?);
        hidden_layers = hidden_layers.add(Activation::Gelu);

        // Intermediate hidden layers (Layer 1 to 6)
        for i in 1..=6 {
            hidden_layers = hidden_layers.add(linear(
                hidden_dim,
                hidden_dim,
                vb.pp(format!("hidden_{}", i)),
            )?);
            hidden_layers = hidden_layers.add(Activation::Gelu);
        }

        let policy_head = linear(hidden_dim, vocab_size, vb.pp("policy_head"))?;
        let value_head = linear(hidden_dim, 1, vb.pp("value_head"))?;

        Ok(Self {
            // token_embedding,
            // position_embedding,
            hidden_layers,
            policy_head,
            value_head,
            span,
        })
    }

    fn forward(&self, tokens: &Tensor) -> Result<(Tensor, Tensor)> {
        let _enter = self.span.enter();
        let (b_sz, seq_len) = tokens.dims2()?;

        // One-Hot Encode Tokens
        // Input `tokens` has shape [batch_size, seq_len] and dtype u32
        let one_hot_tokens = one_hot(tokens.clone(), VOCAB_SIZE, 1.0f32, 0.0f32)?; // Pass owned, cloned tensor

        // Generate Fixed Positional Encodings
        // Output shape [1, seq_len, POS_ENCODING_DIM]
        let position_encodings =
            generate_sinusoidal_positional_encodings(seq_len, POS_ENCODING_DIM, tokens.device())?;
        // Broadcast position encodings to batch size
        let position_encodings =
            position_encodings.broadcast_as((b_sz, seq_len, POS_ENCODING_DIM))?; // Shape [batch_size, seq_len, POS_ENCODING_DIM]

        // Concatenate One-Hot Tokens and Positional Encodings
        // Need to cast one_hot_tokens to float first
        let combined_input = Tensor::cat(
            &[
                one_hot_tokens.to_dtype(DType::F32)?,
                position_encodings.to_dtype(DType::F32)?,
            ],
            D::Minus1, // Concatenate along the last dimension
        )?; // Shape [batch_size, seq_len, VOCAB_SIZE + POS_ENCODING_DIM]
        let combined_input = combined_input.contiguous()?;

        // Pass through hidden layers
        let hidden = self.hidden_layers.forward(&combined_input)?;

        // Select the hidden state corresponding to the *last* token for prediction
        let last_hidden_state = hidden.i((.., seq_len - 1, ..))?;
        let last_hidden_state_contiguous = last_hidden_state.contiguous()?;

        // Generate policy (logits for next token) and value prediction
        let policy_output = self.policy_head.forward(&last_hidden_state_contiguous)?;
        let value_output = self.value_head.forward(&last_hidden_state_contiguous)?; // Currently unused in training/inference logic

        Ok((policy_output, value_output))
    }
}

// --- Data Handling Implementation ---

/// Represents a single data item: a context window and the target token.
#[derive(Debug, Clone)]
pub struct TextItem {
    context: [u32; CONTEXT_WINDOW], // Use u32 for tokens
    target: u32,
}

/// The dataset struct holding all items.
#[derive(Debug, Clone)]
pub struct TextDataset {
    items: Vec<TextItem>,
}

impl TextDataset {
    /// Creates a new dataset from the text file.
    pub fn new(file_path: &str) -> Result<Self> {
        let data = std::fs::read_to_string(file_path)?;
        let data = data.to_lowercase();
        let tokens = tokenize(&data)?;

        println!("Dataset: {} tokens", tokens.len());

        if tokens.len() <= CONTEXT_WINDOW {
            return Err(Error::Msg(format!(
                "Input text must be longer than {} characters",
                CONTEXT_WINDOW
            )));
        }

        let total_sequences = tokens.len() - CONTEXT_WINDOW;
        let mut items = Vec::with_capacity(total_sequences);
        // Use a seeded RNG for reproducibility if needed
        let mut rng = StdRng::seed_from_u64(42); // Example seed

        for i in 0..total_sequences {
            let start = i;
            let end = start + CONTEXT_WINDOW;
            let target_token = tokens[end];

            let sequence_u32 = &tokens[start..end];
            let mut context_array = [0u32; CONTEXT_WINDOW]; // Initialize with 0 or a pad token
            context_array.copy_from_slice(sequence_u32);

            items.push(TextItem {
                context: context_array,
                target: target_token,
            });
        }

        // Shuffle the items
        items.shuffle(&mut rng);

        Ok(Self { items })
    }

    /// Returns the number of items in the dataset
    pub fn len(&self) -> usize {
        self.items.len()
    }

    /// Returns true if the dataset contains no items.
    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    /// Splits the dataset into training and testing sets.
    pub fn split(&self, train_ratio: f32) -> (Self, Self) {
        let n_train = (self.items.len() as f32 * train_ratio).round() as usize;
        let (train_items, test_items) = self.items.split_at(n_train);

        let train_dataset = Self {
            items: train_items.to_vec(),
        };
        let test_dataset = Self {
            items: test_items.to_vec(),
        };

        (train_dataset, test_dataset)
    }

    pub fn iter(&self) -> impl Iterator<Item = &TextItem> {
        self.items.iter()
    }
}

impl std::ops::Deref for TextDataset {
    type Target = Vec<TextItem>;

    fn deref(&self) -> &Self::Target {
        &self.items
    }
}

// Modify TextBatcher to work directly with Candle Tensors
pub struct TextBatcher {
    dataset: Arc<TextDataset>,
    device: Device,
    indices: Vec<usize>, // Store shuffled indices
    batch_size: usize,
    current_index: usize,
}

impl TextBatcher {
    pub fn new(dataset: Arc<TextDataset>, batch_size: usize, device: &Device) -> Self {
        let mut indices: Vec<usize> = (0..dataset.len()).collect();
        // Shuffle indices at the start of each epoch (or here for simplicity)
        let mut rng = StdRng::seed_from_u64(42); // Use same seed or a new one
        indices.shuffle(&mut rng);

        Self {
            dataset,
            device: device.clone(),
            indices,
            batch_size,
            current_index: 0,
        }
    }
}

impl Iterator for TextBatcher {
    // Return Result as tensor creation can fail
    type Item = Result<(Tensor, Tensor)>;

    fn next(&mut self) -> Option<Self::Item> {
        let start = self.current_index;
        let end = (start + self.batch_size).min(self.indices.len());

        if start >= end {
            // Reset for next epoch if needed, or just end iteration
            return None;
        }

        let batch_indices = &self.indices[start..end];
        let current_batch_size = batch_indices.len();

        let mut contexts_flat = Vec::with_capacity(current_batch_size * CONTEXT_WINDOW);
        let mut targets_vec = Vec::with_capacity(current_batch_size);

        for &idx in batch_indices {
            if let Some(item) = self.dataset.items.get(idx) {
                contexts_flat.extend_from_slice(&item.context);
                targets_vec.push(item.target);
            } else {
                // Handle potential index out of bounds, though unlikely with Vec<usize>
                return Some(Err(Error::Msg(format!("Index {} out of bounds", idx))));
            }
        }

        // Create tensors directly on the target device
        let input_tensor_res = Tensor::from_vec(
            contexts_flat,
            (current_batch_size, CONTEXT_WINDOW),
            &self.device,
        );
        let target_tensor_res = Tensor::from_vec(
            targets_vec,        // Targets are u32
            current_batch_size, // Shape is [batch_size]
            &self.device,
        );

        self.current_index = end;

        // Combine results
        match (input_tensor_res, target_tensor_res) {
            (Ok(inputs), Ok(targets)) => Some(Ok((inputs, targets))),
            (Err(e), _) => Some(Err(e)),
            (_, Err(e)) => Some(Err(e)),
        }
    }
}

/// Predicts the next token based on the given context using argmax.
fn predict_next_token(model: &TheNn, context_tokens: Vec<u32>, device: &Device) -> Result<u32> {
    let context_len = context_tokens.len();
    if context_len > CONTEXT_WINDOW {
        return Err(Error::Msg(format!(
            "Input context too long ({}), max is {}",
            context_len, CONTEXT_WINDOW
        )));
    }

    // Pad the context if shorter than CONTEXT_WINDOW
    let mut context_padded = vec![PADDING_TOKEN_ID; CONTEXT_WINDOW]; // Pad with PADDING_TOKEN_ID
    let start_index = CONTEXT_WINDOW - context_len;
    context_padded[start_index..].copy_from_slice(&context_tokens);

    // Create tensor for a single batch item
    let input_tensor = Tensor::from_vec(context_padded, (1, CONTEXT_WINDOW), device)?;

    // Get model predictions (logits for the next token)
    // forward now returns prediction for the *last* token position automatically
    let (logits_output, _value_output) = model.forward(&input_tensor)?; // Shape (1, VOCAB_SIZE)

    // Argmax to find the most likely next token ID
    let next_token_tensor = logits_output.argmax(1)?; // Argmax along the vocab dimension
    let next_token = next_token_tensor.to_scalar::<u32>()?; // Get the u32 token ID

    Ok(next_token)
}

/// Trains the model using the TextBatcher and AdamW optimizer.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap,
    dataset: Arc<TextDataset>,
    device: Device,
) -> Result<()> {
    // TODO: implement recurrent saving of model (checkpoints) every N minutes

    // Initialize optimizer params with BASE_LR (actual LR set each step)
    let params = ParamsAdamW {
        lr: BASE_LR,
        ..Default::default()
    };
    let mut opt = AdamW::new(vars, params)?;

    let report_interval = Duration::from_secs(10); // Report progress interval
    let checkpoint_interval = Duration::from_secs(CHECKPOINT_INTERVAL_MINS * 60); // Checkpoint interval

    let mut last_report_time = Instant::now();
    let mut last_checkpoint_time = Instant::now();
    let training_start_time = Instant::now();

    let mut interval_loss = 0.0f32;
    let mut interval_batches = 0u32;
    let mut total_batches_processed: u64 = 0;

    println!(
        "Starting training with CLR: Base LR={:.1e}, Max LR={:.1e}, Step Size Up={}",
        BASE_LR, MAX_LR, STEP_SIZE_UP_ITERS
    );

    for epoch in 1..=EPOCHS {
        let mut batch_count = 0;
        let batcher = TextBatcher::new(dataset.clone(), BATCH_SIZE, &device);

        for batch_result in batcher {
            total_batches_processed += 1;
            let now = Instant::now(); // Get current time for reports/checkpoints

            match batch_result {
                Ok((inputs, targets)) => {
                    // --- Calculate CLR ---
                    let cycle = (total_batches_processed as f64
                        / (2.0 * STEP_SIZE_UP_ITERS as f64))
                        .floor();
                    let x = (total_batches_processed as f64 / STEP_SIZE_UP_ITERS as f64
                        - 2.0 * cycle)
                        .abs();
                    let current_lr = BASE_LR + (MAX_LR - BASE_LR) * (1.0 - x).max(0.0);
                    opt.set_learning_rate(current_lr);
                    // ---------------------

                    let (logits, _value) = model.forward(&inputs)?;
                    let loss = cross_entropy(&logits, &targets)?;
                    let loss_f32 = loss.to_scalar::<f32>()?;
                    opt.backward_step(&loss)?;

                    interval_loss += loss_f32;
                    batch_count += 1;
                    interval_batches += 1;

                    // --- Time-based progress reporting ---
                    if now.duration_since(last_report_time) >= report_interval {
                        let elapsed_interval = now.duration_since(last_report_time).as_secs_f32();
                        let avg_interval_loss = if interval_batches > 0 {
                            interval_loss / interval_batches as f32
                        } else {
                            0.0
                        };
                        let total_elapsed_in_if = training_start_time.elapsed().as_secs_f32(); // Keep for printing
                        println!(
                            "Epoch: {}, Batch: {}, Total Time: {:.1}s, Interval Time: {:.1}s, Batches/sec: {:.1}, Avg Interval Loss: {:.4}, LR: {:.1e}",
                            epoch,
                            batch_count,
                            total_elapsed_in_if, // Use the value calculated inside
                            elapsed_interval,
                            interval_batches as f32 / elapsed_interval,
                            avg_interval_loss,
                            current_lr // Also report current LR
                        );
                        // Reset interval tracking
                        interval_loss = 0.0;
                        interval_batches = 0;
                        last_report_time = now;
                        io::stdout().flush()?;
                    }

                    // Define total_elapsed here so it's available for checkpointing
                    let total_elapsed = training_start_time.elapsed().as_secs_f32();

                    // --- Periodic checkpoint saving ---
                    if now.duration_since(last_checkpoint_time) >= checkpoint_interval {
                        // Use the passed-in varmap for saving
                        match varmap.save("model_checkpoint.safetensors") {
                            Ok(()) => {
                                println!(
                                    "Checkpoint saved at {} minutes",
                                    (total_elapsed / 60.0).round()
                                );
                                last_checkpoint_time = now;
                            }
                            Err(e) => {
                                eprintln!("Failed to save checkpoint: {}", e);
                            }
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Batch error: {}", e);
                    continue;
                }
            }
        }

        // Save final checkpoint at end of epoch (removed always-true if epoch % 1 == 0)
        // Use the passed-in varmap for saving
        match varmap.save(format!("model_epoch_{}.safetensors", epoch)) {
            Ok(()) => println!("Saved epoch {} checkpoint", epoch),
            Err(e) => eprintln!("Failed to save epoch {} checkpoint: {}", epoch, e),
        }
    }

    Ok(())
}

// --- Positional Encoding Implementation ---
fn generate_sinusoidal_positional_encodings(
    seq_len: usize,
    dim: usize,
    device: &Device,
) -> Result<Tensor> {
    if dim % 2 != 0 {
        return Err(Error::Msg(
            "Positional encoding dimension must be even".to_string(),
        ));
    }
    let mut pos_enc = vec![0.0f32; seq_len * dim];

    for pos in 0..seq_len {
        for i in 0..(dim / 2) {
            let div_term = (10000.0f32).powf((2 * i) as f32 / dim as f32);
            let angle = pos as f32 / div_term;

            let sin_idx = pos * dim + 2 * i;
            let cos_idx = pos * dim + 2 * i + 1;

            if sin_idx < pos_enc.len() {
                pos_enc[sin_idx] = angle.sin();
            }
            if cos_idx < pos_enc.len() {
                pos_enc[cos_idx] = angle.cos();
            }
        }
    }

    Tensor::from_vec(pos_enc, (1, seq_len, dim), device)
}

// --- Main Function ---
#[derive(Debug)]
pub enum TextError {
    IoError(std::io::Error),
    CandleError(candle_core::Error),
    DataError(String),
}

impl std::fmt::Display for TextError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TextError::IoError(e) => write!(f, "IO error: {}", e),
            TextError::CandleError(e) => write!(f, "Candle error: {}", e),
            TextError::DataError(e) => write!(f, "Data error: {}", e),
        }
    }
}

impl From<candle_core::Error> for TextError {
    fn from(e: candle_core::Error) -> Self {
        TextError::CandleError(e)
    }
}

impl From<std::io::Error> for TextError {
    fn from(e: std::io::Error) -> Self {
        TextError::IoError(e)
    }
}

fn main() -> std::result::Result<(), TextError> {
    let args = Args::parse();

    // Get device
    let device = get_default_device(args.cpu, args.cuda)?;
    println!("Using device: {:?}", device);

    // Load dataset
    let file_path = args
        .train_data
        .ok_or_else(|| TextError::DataError("No training data file provided".to_string()))?;
    let dataset = match TextDataset::new(&file_path) {
        // Pass reference
        Ok(d) => Arc::new(d),
        Err(e) => {
            return Err(TextError::DataError(format!(
                "Failed to load dataset: {}",
                e
            )));
        }
    };

    // Create VarMap first, then VarBuilder from it
    let varmap = VarMap::new();
    let vb = VB::from_varmap(&varmap, DType::F32, &device);

    // Create model
    let model = match TheNn::new(vb, VOCAB_SIZE, CONTEXT_WINDOW) {
        Ok(m) => m,
        Err(e) => return Err(TextError::CandleError(e)),
    };

    // Train model using the existing varmap and extracted variables
    let vars = varmap.all_vars(); // Get variables AFTER model creation
    match train_model(&model, vars, &varmap, dataset, device.clone()) {
        // Pass Vec<Var> and &VarMap
        Ok(()) => println!("Training completed successfully"),
        Err(e) => eprintln!("Training failed: {}", e),
    }

    // Interactive inference loop
    println!("\nEnter text to get predictions (type 'exit' to quit):");
    loop {
        print!("> ");
        io::stdout().flush()?;

        let mut input_text = String::new();
        io::stdin().read_line(&mut input_text)?;

        let input_text = input_text.trim();
        if input_text.eq_ignore_ascii_case("exit") {
            break;
        }

        let tokens = match tokenize(input_text) {
            Ok(t) => t,
            Err(e) => {
                eprintln!("Tokenization error: {}", e);
                continue;
            }
        };

        let inference_model = &model; // Use reference to the existing model

        let next_token = match predict_next_token(inference_model, tokens, &device) {
            // Pass the reference
            Ok(t) => t,
            Err(e) => {
                eprintln!("Prediction error: {}", e);
                continue;
            }
        };

        let char = match detokenize(next_token) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("Detokenization error: {}", e);
                continue;
            }
        };

        println!("Next token: {} ({})", char, next_token);
    }

    Ok(())
}
