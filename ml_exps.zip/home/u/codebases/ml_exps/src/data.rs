use candle_core::{Device, Error, Result, Tensor, DType};
use rand::prelude::*;
use rand::rngs::StdRng;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::sync::Arc;
use crate::constants::{
    MAX_COMBINED_LEN, PADDING_TOKEN_ID, SOS_TOKEN_ID, EOS_TOKEN_ID, // Removed CONTEXT_WINDOW if not used
};
use crate::tokenization::tokenize;

// Define the delimiter for Q-A pairs
const QA_DELIMITER: &str = "|||";

/// Represents a single data item: a combined Q-A sequence and the original question length.
#[derive(Debug, Clone)]
pub struct TextItem {
    combined: [u32; MAX_COMBINED_LEN], // Padded sequence: [Question] [SOS] [Answer] [EOS] [PAD...]
    question_len: usize, // Length of the original question (before padding, excluding SOS)
}

/// The dataset struct holding all Q-A items.
#[derive(Debug, Clone)]
pub struct TextDataset {
    items: Vec<TextItem>,
}

impl TextDataset {
    /// Creates a new dataset from a file containing question|||answer pairs per line.
    pub fn new(file_path: &str) -> Result<Self> {
        let file = File::open(file_path).map_err(|e| Error::Msg(format!("Failed to open file: {}", e)))?;
        let reader = BufReader::new(file);
        let mut items = Vec::new();
        let mut line_num = 0;

        for line_result in reader.lines() {
            line_num += 1;
            let line = line_result.map_err(|e| Error::Msg(format!("Failed to read line {}: {}", line_num, e)))?;
            let parts: Vec<&str> = line.split(QA_DELIMITER).collect();

            if parts.len() != 2 {
                eprintln!("Warning: Skipping line {}: Expected 2 parts separated by '{}', found {}", line_num, QA_DELIMITER, parts.len());
                continue;
            }

            let question_str = parts[0].trim();
            let answer_str = parts[1].trim();

            if question_str.is_empty() || answer_str.is_empty() {
                eprintln!("Warning: Skipping line {}: Question or answer is empty.", line_num);
                continue;
            }

            // Tokenize question and answer
            let question_tokens = tokenize(question_str)?;
            let answer_tokens = tokenize(answer_str)?;

            let q_len = question_tokens.len();

            // Build the combined sequence: [Question] [SOS] [Answer] [EOS]
            let mut combined_tokens = Vec::with_capacity(q_len + answer_tokens.len() + 2);
            combined_tokens.extend(&question_tokens);
            combined_tokens.push(SOS_TOKEN_ID);
            combined_tokens.extend(&answer_tokens);
            combined_tokens.push(EOS_TOKEN_ID);

            // --- Pad/Truncate Combined Sequence ---
            let mut combined_array = [PADDING_TOKEN_ID; MAX_COMBINED_LEN];
            let combined_len = combined_tokens.len().min(MAX_COMBINED_LEN);
            combined_array[..combined_len].copy_from_slice(&combined_tokens[..combined_len]);

            // Ensure question_len doesn't exceed MAX_COMBINED_LEN
            let stored_q_len = q_len.min(MAX_COMBINED_LEN);

            items.push(TextItem {
                combined: combined_array,
                question_len: stored_q_len,
            });
        }

        println!("Dataset: Loaded {} Q-A pairs", items.len());

        if items.is_empty() {
            return Err(Error::Msg("No valid Q-A pairs found in the input file.".to_string()));
        }

        let mut rng = StdRng::seed_from_u64(0); // Fixed seed for initial shuffle
        items.shuffle(&mut rng);
        Ok(Self { items })
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    // Split function remains the same conceptually
    pub fn split(&self, train_ratio: f32) -> (Self, Self) {
        let n_train = (self.items.len() as f32 * train_ratio).round() as usize;
        let (train_items, test_items) = self.items.split_at(n_train);

        let train_dataset = Self { items: train_items.to_vec() };
        let test_dataset = Self { items: test_items.to_vec() };

        (train_dataset, test_dataset)
    }
    
    pub fn iter(&self) -> impl Iterator<Item = &TextItem> {
        self.items.iter()
    }
}


// TextBatcher for creating batches of Q-A tensors
pub struct TextBatcher {
    dataset: Arc<TextDataset>,
    device: Device,
    indices: Vec<usize>,
    batch_size: usize,
    current_index: usize,
}

impl TextBatcher {
    pub fn new(
        dataset: Arc<TextDataset>,
        batch_size: usize,
        device: &Device,
        epoch: usize, // Seed RNG per epoch
    ) -> Self {
        let mut indices: Vec<usize> = (0..dataset.len()).collect();
        let mut rng = StdRng::seed_from_u64(42 + epoch as u64);
        indices.shuffle(&mut rng);

        Self {
            dataset,
            device: device.clone(),
            indices,
            batch_size,
            current_index: 0,
        }
    }
}

impl Iterator for TextBatcher {
    // Item is now a batch of combined sequences and a batch of question lengths
    type Item = Result<(Tensor, Tensor)>; // (combined_batch, q_len_batch)

    fn next(&mut self) -> Option<Self::Item> {
        let start = self.current_index;
        let end = (start + self.batch_size).min(self.indices.len());

        if start >= end {
            return None; // End of epoch
        }

        let batch_indices = &self.indices[start..end];
        let current_batch_size = batch_indices.len();

        let mut combined_flat = Vec::with_capacity(current_batch_size * MAX_COMBINED_LEN);
        let mut q_lens_vec = Vec::with_capacity(current_batch_size);

        for &idx in batch_indices {
            let item = &self.dataset.items[idx];
            combined_flat.extend_from_slice(&item.combined);
            // Store question lengths as u32 for tensor creation
            q_lens_vec.push(item.question_len as u32);
        }

        let combined_res = Tensor::from_vec(
            combined_flat,
            (current_batch_size, MAX_COMBINED_LEN),
            &self.device,
        );
        // Create tensor for question lengths
        let q_lens_res = Tensor::from_vec(
            q_lens_vec,
            current_batch_size,
            &self.device,
        );

        self.current_index = end;

        // Handle potential tensor creation errors
        match (combined_res, q_lens_res) {
            (Ok(combined), Ok(q_lens)) => Some(Ok((combined, q_lens))),
            (Err(e), _) => Some(Err(e)), // Propagate the first error encountered
            (_, Err(e)) => Some(Err(e)),
        }
    }
} 