use candle_core::{Error, Result}; 
// use rand::seq::SliceRandom; 
// use rand::thread_rng; 
// use serde_json::Value; 
use std::fs::File;
use std::io::{BufReader, BufRead}; 
use std::path::Path;
use std::sync::Arc; 
use serde::Deserialize;
// Removed: use crate::utils::tokenize; 

use crate::constants::{EOS_TOKEN_ID, MAX_COMBINED_LEN, PADDING_TOKEN_ID, SOS_TOKEN_ID};


/// Represents a single Q-A pair as read from JSON
#[derive(Deserialize, Debug)]
struct QAJsonItem {
    question: String,
    answer: String,
}

/// Represents a single data item: a combined Q-A sequence and the original question length.
#[derive(Debug, Clone)]
pub struct TextItem {
    pub combined: [u32; MAX_COMBINED_LEN], // Padded sequence: [Question] [SOS] [Answer] [EOS] [PAD...]
    pub question_len: usize,          // Length of the original question (before padding, excluding SOS)
}

#[derive(Debug, Clone)]
pub struct TextDataset {
    pub items: Vec<TextItem>,
}

impl TextDataset {
    /// Create a new dataset from a JSONL file where each line is a JSON object
    /// with "question" and "answer" string fields.
    pub fn from_jsonl<P: AsRef<Path>>(path: P) -> Result<Self> {
        let file = File::open(path.as_ref()).map_err(|e| Error::Msg(format!("Failed to open file {}: {}", path.as_ref().display(), e)))?;
        let reader = BufReader::new(file);
        let mut items = Vec::new();

        for line_result in reader.lines() { 
            let line = line_result.map_err(Error::wrap)?;
            if line.trim().is_empty() {
                continue;
            }
            let qa_item: QAJsonItem = serde_json::from_str(&line).map_err(|e| Error::Msg(format!("Failed to parse JSON line: {}. Content: '{}'", e, line)))?;

            let question_str = qa_item.question.trim();
            let answer_str = qa_item.answer.trim();

            // Tokenize question and answer using the utils::tokenize function
            let question_tokens = crate::utils::tokenize(question_str)?;
            let answer_tokens = crate::utils::tokenize(answer_str)?;
            let q_len = question_tokens.len();

            // Build the combined sequence: [Question] [SOS] [Answer] [EOS]
            let mut combined_tokens = Vec::with_capacity(q_len + answer_tokens.len() + 2);
            combined_tokens.extend(&question_tokens);
            combined_tokens.push(SOS_TOKEN_ID);
            combined_tokens.extend(&answer_tokens);
            combined_tokens.push(EOS_TOKEN_ID);

            // --- Pad/Truncate Combined Sequence ---
            let mut combined_array = [PADDING_TOKEN_ID; MAX_COMBINED_LEN];
            let combined_len_to_copy = combined_tokens.len().min(MAX_COMBINED_LEN);
            combined_array[..combined_len_to_copy].copy_from_slice(&combined_tokens[..combined_len_to_copy]);

            // Ensure question_len doesn't exceed MAX_COMBINED_LEN and refers to token count
            let stored_q_len = q_len.min(MAX_COMBINED_LEN);

            items.push(TextItem {
                combined: combined_array,
                question_len: stored_q_len,
            });
        }

        if items.is_empty() {
            return Err(Error::Msg(
                "Dataset is empty or failed to parse any items.".to_string(),
            ));
        }

        Ok(Self { items })
    }
}

/// Simple batcher that yields single items (batch size = 1).
#[derive(Clone)]
pub struct TextBatcher {
    dataset: Arc<TextDataset>, 
    indices: Vec<usize>,
    current_idx: usize,
}

impl TextBatcher {
    pub fn new(
        dataset: Arc<TextDataset>, 
        shuffle: bool,
    ) -> Self {
        let indices: Vec<usize> = (0..dataset.items.len()).collect(); 
        if shuffle {
            // TODO: Implement proper random shuffle (e.g. using rand crate)
        }
        TextBatcher {
            dataset,
            indices,
            current_idx: 0,
        }
    }

    // Fetches the next batch of tokenized data.
    // Returns Option<TextItem> (cloned).
    pub fn next_batch(&mut self) -> Result<Option<TextItem>> { 
        if self.current_idx >= self.indices.len() {
            return Ok(None); // No more data
        }

        let data_idx = self.indices[self.current_idx];
        self.current_idx += 1;

        let item = self.dataset.items[data_idx].clone(); 
        
        Ok(Some(item))
    }

    pub fn reset(&mut self, shuffle: bool) {
        self.current_idx = 0;
        if shuffle {
            // TODO: Re-shuffle indices if needed
        }
    }
}
