use candle_core::{Device, Error, Result, Tensor};
use rand::prelude::*;
use rand::rngs::StdRng;
use std::sync::Arc;
use crate::constants::{CONTEXT_WINDOW, PADDING_TOKEN_ID};
use crate::tokenization::tokenize;

// --- Data Handling Implementation ---

/// Represents a single data item: a context window and the target token.
#[derive(Debug, Clone)]
pub struct TextItem {
    // Made fields public if needed outside this module, otherwise keep private
    context: [u32; CONTEXT_WINDOW], 
    target: u32,
}

/// The dataset struct holding all items.
#[derive(Debug, Clone)]
pub struct TextDataset {
    // Keep items private, expose functionality through methods
    items: Vec<TextItem>,
}

impl TextDataset {
    /// Creates a new dataset from the text file.
    pub fn new(file_path: &str) -> Result<Self> {
        let data = std::fs::read_to_string(file_path).map_err(|e| Error::Msg(e.to_string()))?;
        let data = data.to_lowercase();
        let tokens = tokenize(&data)?;

        println!("Dataset: {} tokens", tokens.len());

        if tokens.is_empty() {
            return Err(Error::Msg("Input text cannot be empty".to_string()));
        }

        let total_sequences = tokens.len();
        let mut items = Vec::with_capacity(total_sequences);
        let mut rng = StdRng::seed_from_u64(0); // Fixed seed for initial shuffle

        for i in 0..total_sequences {
            let target_token = tokens[i];
            let context_start = i.saturating_sub(CONTEXT_WINDOW);
            let actual_context = &tokens[context_start..i];
            
            let mut context_array = [PADDING_TOKEN_ID; CONTEXT_WINDOW];
            let context_len = actual_context.len();
            let pad_len = CONTEXT_WINDOW - context_len;
            context_array[pad_len..].copy_from_slice(actual_context);

            items.push(TextItem {
                context: context_array,
                target: target_token,
            });
        }

        items.shuffle(&mut rng);
        Ok(Self { items })
    }

    pub fn len(&self) -> usize {
        self.items.len()
    }

    pub fn is_empty(&self) -> bool {
        self.items.is_empty()
    }

    // Consider if split logic truly belongs here or in a higher-level orchestrator
    pub fn split(&self, train_ratio: f32) -> (Self, Self) {
        let n_train = (self.items.len() as f32 * train_ratio).round() as usize;
        let (train_items, test_items) = self.items.split_at(n_train);

        let train_dataset = Self { items: train_items.to_vec() };
        let test_dataset = Self { items: test_items.to_vec() };

        (train_dataset, test_dataset)
    }
    
    // Expose items via a method if direct access is needed, avoid Deref if possible
    // pub fn get_items(&self) -> &Vec<TextItem> {
    //     &self.items
    // }
    
    // Provide an iterator method directly
    pub fn iter(&self) -> impl Iterator<Item = &TextItem> {
        self.items.iter()
    }
}

// Removed Deref implementation to encourage using methods like len(), iter(), etc.

// TextBatcher for creating batches of tensors
pub struct TextBatcher {
    dataset: Arc<TextDataset>,
    device: Device,
    indices: Vec<usize>,
    batch_size: usize,
    current_index: usize,
}

impl TextBatcher {
    pub fn new(
        dataset: Arc<TextDataset>,
        batch_size: usize,
        device: &Device,
        epoch: usize, // Seed RNG per epoch
    ) -> Self {
        let mut indices: Vec<usize> = (0..dataset.len()).collect();
        let mut rng = StdRng::seed_from_u64(42 + epoch as u64);
        indices.shuffle(&mut rng);

        Self {
            dataset,
            device: device.clone(),
            indices,
            batch_size,
            current_index: 0,
        }
    }
}

impl Iterator for TextBatcher {
    type Item = Result<(Tensor, Tensor)>;

    fn next(&mut self) -> Option<Self::Item> {
        let start = self.current_index;
        let end = (start + self.batch_size).min(self.indices.len());

        if start >= end {
            return None; // End of epoch
        }

        let batch_indices = &self.indices[start..end];
        let current_batch_size = batch_indices.len();

        // Pre-allocate flat vectors
        let mut contexts_flat = Vec::with_capacity(current_batch_size * CONTEXT_WINDOW);
        let mut targets_vec = Vec::with_capacity(current_batch_size);

        for &idx in batch_indices {
            // Directly access item using index, assuming indices are valid
            let item = &self.dataset.items[idx]; 
            contexts_flat.extend_from_slice(&item.context);
            targets_vec.push(item.target);
        }

        // Create tensors on the target device
        let inputs_res = Tensor::from_vec(
            contexts_flat,
            (current_batch_size, CONTEXT_WINDOW),
            &self.device,
        );
        let targets_res = Tensor::from_vec(
            targets_vec,
            current_batch_size,
            &self.device,
        );

        self.current_index = end;

        // Handle potential tensor creation errors
        match (inputs_res, targets_res) {
            (Ok(inputs), Ok(targets)) => Some(Ok((inputs, targets))),
            (Err(e), _) => Some(Err(e)),
            (_, Err(e)) => Some(Err(e)),
        }
    }
} 