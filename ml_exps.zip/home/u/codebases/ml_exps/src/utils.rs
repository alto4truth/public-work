// No specific imports from candle_core needed if not directly used.

use crate::constants::{SYMBOLS, PADDING_TOKEN_ID};

/// Basic tokenizer: maps each character in `text` to its corresponding
/// token id as defined in `SYMBOLS`. Characters that are **not** present in
/// the vocabulary are mapped to `PADDING_TOKEN_ID` (acts like an "UNK" token).
///
/// This ensures that all produced token IDs are **strictly** lower than
/// `VOCAB_SIZE` so that the subsequent one-hot encoding step does not panic.
pub fn tokenize(text: &str) -> candle_core::Result<Vec<u32>> {
    // Build a lookup table from SYMBOLS at runtime (tiny, 32 elements)
    // Mapping char -> token id (index in SYMBOLS array)
    let mut tokens = Vec::with_capacity(text.len());
    for ch in text.chars() {
        // Find the position of `ch` in SYMBOLS; position() is O(32) – negligible.
        match SYMBOLS.iter().position(|&s| s == ch) {
            Some(idx) => tokens.push(idx as u32),
            None => tokens.push(PADDING_TOKEN_ID), // Unknown character → PAD token
        }
    }
    Ok(tokens)
}

// --- Positional Encoding Implementation ---
