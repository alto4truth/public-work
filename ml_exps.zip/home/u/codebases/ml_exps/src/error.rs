#[derive(Debug)]
pub enum TextError {
    IoError(std::io::Error),
    CandleError(candle_core::Error),
    DataError(String),
}

impl std::fmt::Display for TextError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TextError::IoError(e) => write!(f, "IO error: {}", e),
            TextError::CandleError(e) => write!(f, "Candle error: {}", e),
            TextError::DataError(e) => write!(f, "Data error: {}", e),
        }
    }
}

impl From<candle_core::Error> for TextError {
    fn from(e: candle_core::Error) -> Self {
        TextError::CandleError(e)
    }
}

impl From<std::io::Error> for TextError {
    fn from(e: std::io::Error) -> Self {
        TextError::IoError(e)
    }
} 