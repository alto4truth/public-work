use candle_core::{Device, Result};

// Get default device, optionally forcing CPU or CUDA
pub fn get_default_device(_force_cpu: bool, _force_cuda: bool) -> Result<Device> {
    #[cfg(feature = "cuda_backend")]
    {
        if _force_cuda {
            println!("CUDA device explicitly requested via command line.");
            // Attempt to create CUDA device, return error if it fails
            return Device::new_cuda(0).map_err(|e| {
                eprintln!("Failed to create requested CUDA device: {}. Ensure CUDA is installed and compatible.", e);
                e
            });
        }
        if _force_cpu {
            // Use the prefixed variable here
            println!("CPU device explicitly requested via command line.");
            return Ok(Device::Cpu);
        }

        // Default behavior when cuda_backend is enabled: Try CUDA, fallback to CPU
        println!(
            "Checking for CUDA availability (cuda_backend feature enabled, no explicit request)..."
        );
        if candle_core::utils::cuda_is_available() {
            println!("CUDA device available, attempting to use...");
            match Device::new_cuda(0) {
                // Try creating CUDA device
                Ok(dev) => return Ok(dev), // Use CUDA if successful
                Err(e) => {
                    eprintln!("Failed to create CUDA device: {}. Falling back to CPU.", e);
                }
            }
        } else {
            println!("CUDA not available. Falling back to CPU.");
        }
        // Final fallback return for the cfg block
        Ok(Device::Cpu)
    }

    #[cfg(not(feature = "cuda_backend"))]
    {
        println!("Using CPU device (cuda_backend feature not enabled).");
        Ok(Device::Cpu)
    }
}
