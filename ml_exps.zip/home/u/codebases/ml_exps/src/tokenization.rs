use candle_core::{Error, Result};
use crate::constants::{SYMBOLS, VOCAB_SIZE, PADDING_TOKEN_ID, SOS_TOKEN_ID, EOS_TOKEN_ID, BASE_VOCAB_SIZE};

// Tokenize a single character
fn tokenize_char(c: char) -> Result<u32> {
    let c = c.to_ascii_lowercase();
    for (i, &symbol) in SYMBOLS.iter().enumerate() { 
        if symbol == c {
            return Ok(i as u32);
        }
    }
    Err(Error::Msg(format!("Unknown character '{}'", c)))
}

// Tokenize a string
pub fn tokenize(text: &str) -> Result<Vec<u32>> {
    let mut tokens = Vec::new();
    for c in text.chars() {
        match tokenize_char(c) {
            Ok(token) => tokens.push(token),
            Err(_) => continue, // Skip unknown characters
        }
    }
    Ok(tokens)
}

// Detokenize a single token ID
pub fn detokenize(token: u32) -> Result<String> {
    let idx = token as usize;
    if idx < BASE_VOCAB_SIZE {
        Ok(SYMBOLS[idx].to_string())
    } else if token == PADDING_TOKEN_ID {
        Ok("[PAD]".to_string())
    } else if token == SOS_TOKEN_ID {
        Ok("[SOS]".to_string())
    } else if token == EOS_TOKEN_ID {
        Ok("[EOS]".to_string())
    } else {
        Err(Error::Msg(format!(
            "Token {} is out of range (Vocab size: {}, Special IDs: PAD={}, SOS={}, EOS={})",
            token, VOCAB_SIZE, PADDING_TOKEN_ID, SOS_TOKEN_ID, EOS_TOKEN_ID
        )))
    }
} 