use candle_core::{Error, Result};
use crate::constants::{SYMBOLS, VOCAB_SIZE, PADDING_TOKEN_ID};

// Tokenize a single character
fn tokenize_char(c: char) -> Result<u32> {
    let c = c.to_ascii_lowercase();
    for (i, &symbol) in SYMBOLS.iter().enumerate() { 
        if symbol == c {
            return Ok(i as u32);
        }
    }
    Err(Error::Msg(format!("Unknown character '{}'", c)))
}

// Tokenize a string
pub fn tokenize(text: &str) -> Result<Vec<u32>> {
    let mut tokens = Vec::new();
    for c in text.chars() {
        match tokenize_char(c) {
            Ok(token) => tokens.push(token),
            Err(_) => continue, // Skip unknown characters
        }
    }
    Ok(tokens)
}

// Detokenize a single token ID
pub fn detokenize(token: u32) -> Result<char> {
    let idx = token as usize;
    if idx < SYMBOLS.len() { 
        Ok(SYMBOLS[idx])
    } else if idx == PADDING_TOKEN_ID as usize { // Handle explicit padding token ID
        Ok('-') // Placeholder for padding token
    } else {
        Err(Error::Msg(format!(
            "Token {} is out of range (Vocab size: {}, Padding ID: {})",
            token, VOCAB_SIZE, PADDING_TOKEN_ID
        )))
    }
} 