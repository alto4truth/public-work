// --- Constants ---
// const VOCAB_SIZE: usize = 26; // a-z // Replaced by SYMBOLS.len()
pub const CONTEXT_WINDOW: usize = 128; // Increased from 64
pub const EPOCHS: usize = 1_000_000;
pub const BATCH_SIZE: usize = 32;

// Define our symbol vocabulary
pub const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    ' ', '.', ',', '!', '?', '-' // Reverted to 32 symbols
];

// Derive VOCAB_SIZE from SYMBOLS
pub const VOCAB_SIZE: usize = SYMBOLS.len(); // Now 32

// Use an ID outside the valid vocab range for padding
pub const PADDING_TOKEN_ID: u32 = VOCAB_SIZE as u32; // Use VOCAB_SIZE as the padding token ID (now 32)
pub const NUM_HIDDEN_LAYERS: usize = 7; // Added constant for number of hidden layers
pub const HIDDEN_DIM: usize = 128; // Define hidden dimension

// --- CLR Parameters ---
pub const BASE_LR: f64 = 1e-5; // Lower bound for LR cycle
pub const MAX_LR: f64 = 1e-3; // Upper bound for LR cycle (Tune this!)
pub const STEP_SIZE_UP_ITERS: u64 = 292; // Iterations for half a cycle (e.g., 4 * est_iters_per_epoch)
pub const CHECKPOINT_INTERVAL_MINS: u64 = 15; // Save checkpoint every N minutes 