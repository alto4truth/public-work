// --- Constants ---
// CONTEXT_WINDOW might represent the attention span or positional encoding limit if fixed.
// Let's keep it but clarify its potential role. It's not directly used for padding Q/A now.
pub const CONTEXT_WINDOW: usize = 1024; // Max context/attention length?
pub const EPOCHS: usize = 1_000_000;
// pub const BATCH_SIZE: usize = 32; // Removed unused constant

// Define our symbol vocabulary
pub const SYMBOLS: [char; 32] = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
    't', 'u', 'v', 'w', 'x', 'y', 'z', ' ', '.', ',', '!', '?', '-', // Reverted to 32 symbols
];

// Derive VOCAB_SIZE from SYMBOLS
pub const BASE_VOCAB_SIZE: usize = SYMBOLS.len(); // Size of the base character vocabulary (32)

// --- Special Token IDs ---
// Assign IDs starting after the base vocabulary
pub const SOS_TOKEN_ID: u32 = BASE_VOCAB_SIZE as u32; // Start of Sequence/Answer (e.g., 32)
pub const EOS_TOKEN_ID: u32 = (BASE_VOCAB_SIZE + 1) as u32; // End of Sequence/Answer (e.g., 33)
pub const PADDING_TOKEN_ID: u32 = (BASE_VOCAB_SIZE + 2) as u32; // Padding token ID (e.g., 34)

// --- Total Vocabulary Size ---
// Includes base symbols + special tokens (SOS, EOS, PAD)
pub const VOCAB_SIZE: usize = BASE_VOCAB_SIZE + 3; // Base + SOS + EOS + PAD

// --- Sequence Lengths ---
// Max length for the combined "Question + [SOS] + Answer + [EOS]" sequence after tokenization.
// This will be padded to this length.
pub const MAX_COMBINED_LEN: usize = 1024; // Max combined sequence length (adjust as needed)

pub const NUM_HIDDEN_LAYERS: usize = 7; // Added constant for number of hidden layers
pub const HIDDEN_DIM: usize = 128; // Define hidden dimension

// --- CLR Parameters ---
pub const LR: f64 = 1e-4; // Lower bound for LR cycle
// pub const STEP_SIZE_UP_ITERS: u64 = 292; // Iterations for half a cycle (e.g., 4 * est_iters_per_epoch) // Removed unused constant
pub const CHECKPOINT_INTERVAL_MINS: u64 = 15; // Save checkpoint every N minutes
pub const CHECKPOINT_DIR: &str = "checkpoints"; // Directory for model checkpoints

// --- Answer Length ---
pub const MAX_ANSWER_LEN: usize = 100; // Max length for generated answer in chat mode
