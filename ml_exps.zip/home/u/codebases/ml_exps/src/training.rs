use candle_core::{D, DType, Device, Error, IndexOp, Result, Tensor, Var};
use candle_nn::{
    ops::softmax, // Import softmax
    loss::cross_entropy, // Import cross_entropy loss
    optim::{AdamW, ParamsAdamW, Optimizer},
    VarMap,
};
use std::sync::Arc;
use std::time::{Duration, Instant};
use std::io::{self, Write}; // For flushing stdout

use crate::constants::*;
use crate::model::TheNn;
use crate::data::{TextDataset, TextBatcher};
use crate::tokenization::detokenize;

/// Generates an answer sequence given a question sequence.
pub fn generate_answer(
    model: &TheNn,
    question_tokens: Vec<u32>,
    max_len: usize, // Max length of the generated answer (excluding SOS/EOS)
    device: &Device,
) -> Result<Vec<u32>> {
    let mut generated_tokens = Vec::new();
    let mut current_sequence = Vec::with_capacity(MAX_COMBINED_LEN);
    current_sequence.extend(&question_tokens);
    current_sequence.push(SOS_TOKEN_ID);

    for _ in 0..max_len {
        // Prepare input tensor
        let mut input_array = [PADDING_TOKEN_ID; MAX_COMBINED_LEN];
        let seq_len = current_sequence.len().min(MAX_COMBINED_LEN);
        input_array[..seq_len].copy_from_slice(&current_sequence[..seq_len]);
        
        let input_tensor = Tensor::from_slice(&input_array, (1, MAX_COMBINED_LEN), device)?;
        
        // Run model
        let logits = model.forward(&input_tensor)?; // Shape [1, MAX_COMBINED_LEN, VOCAB_SIZE]

        // Get logits for the *next* token prediction (at the end of the current sequence)
        // Index is seq_len - 1 because sequence indices are 0-based
        let next_token_logits = logits.i((0, seq_len.saturating_sub(1)))?; // Shape [VOCAB_SIZE]

        // Argmax to get the most likely next token
        let next_token = next_token_logits.argmax(0)?.to_scalar::<u32>()?;

        if next_token == EOS_TOKEN_ID {
            break; // Stop generation if EOS is predicted
        }

        generated_tokens.push(next_token);
        current_sequence.push(next_token);

        // Optional: Check if current_sequence exceeds MAX_COMBINED_LEN and handle if necessary
        if current_sequence.len() >= MAX_COMBINED_LEN {
             eprintln!("Warning: Generation stopped because MAX_COMBINED_LEN reached.");
             break;
        }
    }

    Ok(generated_tokens)
}

/// Trains the model using Q-A pairs with masked cross-entropy loss.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap,
    dataset: Arc<TextDataset>,
    device: Device,
) -> Result<()> {
    let mut params = ParamsAdamW::default();
    params.lr = BASE_LR;
    // params.weight_decay = 0.01;
    let mut opt = AdamW::new(vars, params)?;

    let report_interval = Duration::from_secs(10);
    let checkpoint_interval = Duration::from_secs(CHECKPOINT_INTERVAL_MINS * 60);
    let mut last_report_time = Instant::now();
    let mut last_checkpoint_time = Instant::now();
    let training_start_time = Instant::now();
    let mut interval_loss = 0.0f32;
    let mut interval_tokens = 0u64;
    let mut total_batches_processed: u64 = 0;

    println!(
        "Starting Q-A training with CLR: Base LR={:.1e}, Max LR={:.1e}, Step Size Up={}",
        BASE_LR, MAX_LR, STEP_SIZE_UP_ITERS
    );

    for epoch in 1..=EPOCHS {
        let mut batch_count = 0;
        let batcher = TextBatcher::new(dataset.clone(), BATCH_SIZE, &device, epoch);

        for batch_result in batcher {
            total_batches_processed += 1;
            let now = Instant::now();

            match batch_result {
                // Batch contains (combined_sequences, question_lengths)
                Ok((combined, q_lens)) => {
                    batch_count += 1;
                    let batch_size = combined.dims()[0];
                    let seq_len = combined.dims()[1]; // Should be MAX_COMBINED_LEN

                    // Prepare inputs and targets for next-token prediction
                    let inputs = combined.i((.., ..seq_len.saturating_sub(1)))?.contiguous()?; // Input: [CLS] ... TokN-1
                    let targets = combined.i((.., 1..))?.contiguous()?;         // Target: Tok1 ... [EOS]

                    // --- Batch Processing Logic with Masked Loss --- 
                    let process_batch = |inputs: Tensor, targets: Tensor, q_lens: Tensor, current_opt: &mut AdamW, current_device: &Device| -> Result<(f32, u64)> {
                        let logits = model.forward(&inputs)?; // Logits shape [B, S-1, V]
                        let (b_size, seq_minus_1, vocab_size) = logits.dims3()?;

                        // Flatten logits and targets for cross_entropy
                        let logits_flat = logits.reshape((b_size * seq_minus_1, vocab_size))?; // Shape [B * (S-1), V]
                        let targets_flat = targets.flatten_to(1)?; // Shape [B * (S-1)]

                        // Create mask to ignore loss from padding and question tokens
                        // Mask shape should match targets_flat: [B * (S-1)]
                        let target_mask = targets.ne(PADDING_TOKEN_ID)?; // Mask padding [B, S-1]

                        // Create sequence position indices [0, 1, ..., S-2] for each batch item
                        let position_indices = Tensor::arange(0u32, seq_len as u32 -1, current_device)?
                            .unsqueeze(0)? // [1, S-1]
                            .expand((batch_size, seq_len - 1))?; // [B, S-1]
                        
                        // Create question length mask (True where index >= q_len)
                        // q_lens has shape [B], needs expansion to [B, S-1]
                        let q_lens_expanded = q_lens.unsqueeze(1)?.broadcast_as(position_indices.shape())?; // [B, S-1]
                        let answer_token_mask = position_indices.ge(&q_lens_expanded)?; // True for SOS_Token + Answer tokens

                        // Combine masks (must be answer token AND not padding)
                        // Use element-wise multiplication for logical AND on boolean tensors (U8)
                        let final_mask = target_mask.mul(&answer_token_mask)?; // [B, S-1]
                        let final_mask_flat = final_mask.flatten_to(1)?; // [B * (S-1)]

                        // Calculate masked cross-entropy loss MANUALLY
                        // Step 1: Log-Softmax
                        let log_probs = candle_nn::ops::log_softmax(&logits_flat, D::Minus1)?; // Shape [N, C] where N = B*(S-1)

                        // Step 2: Gather NLL for target classes
                        // targets_flat needs shape [N, 1] for gather
                        let nll = log_probs.gather(&targets_flat.unsqueeze(D::Minus1)?, D::Minus1)?; // Shape [N, 1]
                        let nll = nll.squeeze(D::Minus1)?; // Shape [N]

                        // Step 3: Apply the mask (using negative nll as loss)
                        let masked_loss = nll.mul(&final_mask_flat.to_dtype(DType::F32)?)?; // Shape [N]

                        // Step 4: Sum the masked losses
                        // Note: cross-entropy is -log(prob), so we sum the negative nll
                        let total_loss = masked_loss.sum_all()?.neg()?; // Scalar

                        // Step 5: Calculate average loss
                        // Convert the sum of the U8 mask to F32 before converting to scalar
                        let num_tokens = final_mask_flat.sum_all()?
                            .to_dtype(DType::F32)?
                            .to_scalar::<f32>()?.max(1.0);
                        let avg_loss = total_loss.div(&Tensor::new(num_tokens, current_device)?)?; // Scalar

                        // Backpropagation
                        let grads = avg_loss.backward()?;
                        current_opt.step(&grads)?;

                        let loss_f32 = avg_loss.to_scalar::<f32>()?;
                        let tokens_u64 = num_tokens as u64;
                        
                        Ok((loss_f32, tokens_u64))
                    };
                    // --- End Batch Processing Logic ---

                    // CLR Calculation
                    let iter = total_batches_processed as f64;
                    let step = STEP_SIZE_UP_ITERS as f64;
                    let cycle = (iter / (2.0 * step)).floor();
                    let x = (iter / step - 2.0 * cycle - 1.0).abs();
                    let current_lr = BASE_LR + (MAX_LR - BASE_LR) * (1.0 - x).max(0.0);
                    opt.set_learning_rate(current_lr);

                    // Process batch
                    match process_batch(inputs, targets, q_lens, &mut opt, &device) {
                        Ok((loss_f32, tokens_calculated)) => {
                            interval_loss += loss_f32 * tokens_calculated as f32; // Accumulate weighted loss
                            interval_tokens += tokens_calculated;

                            // Reporting
                            if now.duration_since(last_report_time) >= report_interval {
                                let elapsed_interval = now.duration_since(last_report_time).as_secs_f32();
                                let avg_interval_loss = if interval_tokens > 0 { interval_loss / interval_tokens as f32 } else { 0.0 };
                                let total_elapsed = training_start_time.elapsed().as_secs_f32();
                                let tokens_per_sec = interval_tokens as f32 / elapsed_interval.max(1e-6);
                                println!(
                                    "Epoch: {}, Batch: {}, Total Time: {:.1}s, Toks/sec: {:.1}, Avg Interval Loss: {:.4}, LR: {:.1e}",
                                    epoch, batch_count, total_elapsed, 
                                    tokens_per_sec, avg_interval_loss, current_lr
                                );
                                interval_loss = 0.0;
                                interval_tokens = 0;
                                last_report_time = now;
                                io::stdout().flush().map_err(|e| Error::Msg(e.to_string()))?;
                            }

                            // Checkpointing (remains the same)
                            if now.duration_since(last_checkpoint_time) >= checkpoint_interval {
                                let total_elapsed_mins = (training_start_time.elapsed().as_secs_f32() / 60.0).round();
                                match varmap.save("model_checkpoint.safetensors") {
                                    Ok(()) => {
                                        println!("Checkpoint saved at {} minutes", total_elapsed_mins);
                                        last_checkpoint_time = now;
                                    }
                                    Err(e) => eprintln!("Failed to save checkpoint: {}", e),
                                }
                            }
                        }
                        Err(e) => {
                            eprintln!("Epoch {}, Batch {}: Skipping batch due to error: {}", epoch, batch_count, e);
                        }
                    }
                }
                Err(e) => {
                    // Handle batcher error
                    batch_count += 1; // Increment even if batcher fails for correct reporting
                    eprintln!("Epoch {}, Batch {}: Batcher error: {}", epoch, batch_count, e);
                }
            }
        }
    }

    Ok(())
} 