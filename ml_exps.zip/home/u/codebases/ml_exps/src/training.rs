use candle_core::{D, DType, Device, Error, Result, Tensor, Var};
use candle_nn::{
    optim::{AdamW, ParamsAdamW, Optimizer},
    VarMap
};
use std::sync::Arc;
use std::time::{Duration, Instant};
use std::io::{self, Write}; // For flushing stdout

use crate::constants::*;
use crate::model::TheNn;
use crate::data::{TextDataset, TextBatcher};

/// Predicts the next token based on the given context using argmax.
pub fn predict_next_token(model: &TheNn, context_tokens: Vec<u32>, device: &Device) -> Result<u32> {
    let context_len = context_tokens.len();
    let context_start_index = context_len.saturating_sub(CONTEXT_WINDOW);
    let actual_context_slice = &context_tokens[context_start_index..];
    let actual_context_len = actual_context_slice.len();
    
    let mut context_array = [PADDING_TOKEN_ID; CONTEXT_WINDOW];
    let pad_len = CONTEXT_WINDOW - actual_context_len;
    context_array[pad_len..].copy_from_slice(actual_context_slice);
    
    let input_tensor = Tensor::from_slice(&context_array, (1, CONTEXT_WINDOW), device)?;
    let logits_output = model.forward(&input_tensor)?; 
    let next_token_tensor = logits_output.argmax(D::Minus1)?; 
    let next_token = next_token_tensor.to_scalar::<u32>()?;

    Ok(next_token)
}

/// Trains the model using the TextBatcher and AdamW optimizer.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap, // Need varmap for saving checkpoints
    dataset: Arc<TextDataset>,
    device: Device, // Take ownership or clone depending on needs
) -> Result<()> {
    
    let mut params = ParamsAdamW::default();
    params.lr = BASE_LR;
    params.weight_decay = 0.0f64; 
    let mut opt = AdamW::new(vars, params)?;

    let report_interval = Duration::from_secs(10); 
    let checkpoint_interval = Duration::from_secs(CHECKPOINT_INTERVAL_MINS * 60);

    let mut last_report_time = Instant::now();
    let mut last_checkpoint_time = Instant::now();
    let training_start_time = Instant::now();

    let mut interval_loss = 0.0f32;
    let mut interval_batches = 0u32;
    let mut total_batches_processed: u64 = 0;

    println!(
        "Starting training with CLR: Base LR={:.1e}, Max LR={:.1e}, Step Size Up={}",
        BASE_LR, MAX_LR, STEP_SIZE_UP_ITERS
    );

    for epoch in 1..=EPOCHS {
        let mut batch_count = 0;
        let batcher = TextBatcher::new(dataset.clone(), BATCH_SIZE, &device, epoch);

        for batch_result in batcher {
            total_batches_processed += 1;
            let now = Instant::now(); 

            match batch_result {
                Ok((inputs, targets)) => {
                    // --- Batch Processing Logic --- 
                    let process_batch = |inputs: Tensor, targets: Tensor, current_opt: &mut AdamW, current_device: &Device| -> Result<f32> {
                        let logits = model.forward(&inputs)?;
                        let log_probs = candle_nn::ops::log_softmax(&logits, D::Minus1)?;
                        let targets_expanded = targets.unsqueeze(D::Minus1)?;
                        let gathered_log_probs = log_probs.gather(&targets_expanded, D::Minus1)?.squeeze(D::Minus1)?;
                        let mask = targets.ne(PADDING_TOKEN_ID)?.to_dtype(DType::F32)?;
                        let masked_neg_log_probs = (gathered_log_probs * &mask)?.neg()?;
                        let sum_loss = masked_neg_log_probs.sum_all()?;
                        let num_tokens = mask.sum_all()?.to_scalar::<f32>()?.max(1.0); // Avoid division by zero
                        let loss = sum_loss.div(&Tensor::new(num_tokens, current_device)?)?; 
                        
                        let grads = loss.backward()?;
                        let loss_f32 = loss.to_scalar::<f32>()?;
                        current_opt.step(&grads)?;
                        
                        Ok(loss_f32)
                    };
                    // --- End Batch Processing Logic ---

                    // CLR Calculation
                    let iter = total_batches_processed as f64;
                    let step = STEP_SIZE_UP_ITERS as f64;
                    let cycle = (iter / (2.0 * step)).floor();
                    let x = (iter / step - 2.0 * cycle - 1.0).abs();
                    let current_lr = BASE_LR + (MAX_LR - BASE_LR) * (1.0 - x).max(0.0);
                    opt.set_learning_rate(current_lr);
                                        
                    // Process batch
                    match process_batch(inputs, targets, &mut opt, &device) {
                        Ok(loss_f32) => {
                            interval_loss += loss_f32;
                            batch_count += 1;
                            interval_batches += 1;
                            
                            // Reporting
                            if now.duration_since(last_report_time) >= report_interval {
                                let elapsed_interval = now.duration_since(last_report_time).as_secs_f32();
                                let avg_interval_loss = if interval_batches > 0 { interval_loss / interval_batches as f32 } else { 0.0 };
                                let total_elapsed = training_start_time.elapsed().as_secs_f32();
                                println!(
                                    "Epoch: {}, Batch: {}, Total Time: {:.1}s, Interval Time: {:.1}s, Batches/sec: {:.1}, Avg Interval Loss: {:.4}, LR: {:.1e}",
                                    epoch, batch_count, total_elapsed, elapsed_interval,
                                    interval_batches as f32 / elapsed_interval.max(1e-6), // Avoid div by zero
                                    avg_interval_loss, current_lr
                                );
                                interval_loss = 0.0;
                                interval_batches = 0;
                                last_report_time = now;
                                io::stdout().flush().map_err(|e| Error::Msg(e.to_string()))?; // Handle potential IO error
                            }

                            // Checkpointing
                            if now.duration_since(last_checkpoint_time) >= checkpoint_interval {
                                let total_elapsed_mins = (training_start_time.elapsed().as_secs_f32() / 60.0).round();
                                match varmap.save("model_checkpoint.safetensors") {
                                    Ok(()) => {
                                        println!("Checkpoint saved at {} minutes", total_elapsed_mins);
                                        last_checkpoint_time = now;
                                    }
                                    Err(e) => eprintln!("Failed to save checkpoint: {}", e),
                                }
                            }
                        }
                        Err(e) => {
                            eprintln!("Epoch {}, Batch {}: Skipping batch due to error: {}", epoch, batch_count + 1, e);
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Epoch {}, Batch {}: Batcher error: {}", epoch, batch_count + 1, e);
                }
            }
        }
    }

    Ok(())
} 