use candle_core::{D, DType, Device, IndexOp, Result, Tensor, Var};
use candle_nn::{
    VarMap,
    optim::{AdamW, Optimizer, ParamsAdamW},
};
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::constants::*;
use crate::data::TextDataset;
use crate::data::TextBatcher;
use crate::model::TheNn;

/// Generates an answer sequence given a question sequence.
pub fn generate_answer(
    model: &TheNn,
    question_tokens: Vec<u32>,
    max_len: usize, // Max length of the generated answer (excluding SOS/EOS)
    device: &Device,
) -> Result<Vec<u32>> {
    let mut generated_tokens = Vec::new();
    let mut current_sequence = Vec::with_capacity(MAX_COMBINED_LEN);
    current_sequence.extend(&question_tokens);
    current_sequence.push(SOS_TOKEN_ID);

    for _ in 0..max_len {
        // Prepare input tensor
        let mut input_array = [PADDING_TOKEN_ID; MAX_COMBINED_LEN];
        let seq_len = current_sequence.len().min(MAX_COMBINED_LEN);
        input_array[..seq_len].copy_from_slice(&current_sequence[..seq_len]);

        let input_tensor = Tensor::from_slice(&input_array, (1, MAX_COMBINED_LEN), device)?;

        // Run model
        let logits = model.forward(&input_tensor)?; // Shape [1, MAX_COMBINED_LEN, VOCAB_SIZE]

        // Get logits for the *next* token prediction (at the end of the current sequence)
        // Index is seq_len - 1 because sequence indices are 0-based
        let next_token_logits = logits.i((0, seq_len.saturating_sub(1)))?; // Shape [VOCAB_SIZE]

        // Argmax to get the most likely next token
        let next_token = next_token_logits.argmax(0)?.to_scalar::<u32>()?;

        if next_token == EOS_TOKEN_ID {
            break; // Stop generation if EOS is predicted
        }

        generated_tokens.push(next_token);
        current_sequence.push(next_token);

        // Optional: Check if current_sequence exceeds MAX_COMBINED_LEN and handle if necessary
        if current_sequence.len() >= MAX_COMBINED_LEN {
            eprintln!("Warning: Generation stopped because MAX_COMBINED_LEN reached.");
            break;
        }
    }

    Ok(generated_tokens)
}

/// Trains the model using Q-A pairs with masked cross-entropy loss.
pub fn train_model(
    model: &TheNn,
    vars: Vec<Var>,
    varmap: &VarMap,
    dataset: Arc<TextDataset>,
    device: Device,
) -> Result<()> {
    // --- Optimiser setup ---
    let mut params = ParamsAdamW::default();
    params.lr = LR;
    let mut opt = AdamW::new(vars, params)?;

    let checkpoint_interval = Duration::from_secs(CHECKPOINT_INTERVAL_MINS * 60);
    let mut last_checkpoint_time = Instant::now();

    println!("Starting Q-A training (Batcher, LR = {:.1e})", LR);

    // --- Batcher Setup ---
    let mut batcher = TextBatcher::new(dataset.clone(), true);

    for epoch in 1..=EPOCHS {
        println!("Epoch {}", epoch);
        let mut sample_idx = 0usize;
        let mut total_loss_epoch = 0f32;
        let mut num_batches_epoch = 0usize;

        batcher.reset(true); // Reset and shuffle for each epoch

        while let Some(item) = batcher.next_batch()? {
            sample_idx += 1;

            // Build tensors for this sample ------------------------------
            let combined = Tensor::from_slice(&item.combined, (1, MAX_COMBINED_LEN), &device)?;

            // Detect actual (non-PAD) sequence length for dynamic slicing
            let non_pad_mask = combined.ne(PADDING_TOKEN_ID)?; // [1, S] (U8)
            let seq_len_tensor = non_pad_mask
                .to_dtype(DType::U32)? // Cast to U32 so the sum result is U32
                .sum(D::Minus1)?; // [1]

            let seq_len = seq_len_tensor
                .squeeze(0)?
                .to_scalar::<u32>()?
                .max(2) as usize; // need at least 2 tokens

            let inputs = combined.i((.., ..seq_len - 1))?.contiguous()?; // [1, seq_len-1]
            let targets = combined.i((.., 1..seq_len))?.contiguous()?; // [1, seq_len-1]

            // Forward pass ----------------------------------------------
            let logits = model.forward(&inputs)?; // [1, S-1, V]
            let (_b, seq_minus_1, _vocab_size) = logits.dims3()?; // S-1 == seq_len-1

            // Flatten logits/targets for loss ---------------------------
            let logits_flat = logits.flatten_to(1)?; // [ (S-1), V ] because B=1
            let targets_flat = targets.flatten_to(1)?; // [ S-1 ]

            // --- Masking ---
            let target_mask = targets.ne(PADDING_TOKEN_ID)?; // [1, S-1]

            let position_indices =
                Tensor::arange(0u32, seq_minus_1 as u32, &device)?.unsqueeze(0)?; // [1, S-1]

            // answer tokens start strictly after SOS => index > q_len
            let q_len_tensor = Tensor::new(item.question_len as u32, &device)?
                .unsqueeze(0)?
                .expand((1, seq_minus_1))?; // [1, S-1]

            let answer_mask = position_indices.gt(&q_len_tensor)?; // [1, S-1]

            let final_mask = target_mask.mul(&answer_mask)?; // [1, S-1]
            let final_mask_flat = final_mask.flatten_to(1)?; // [S-1]

            // --- Loss ---
            let log_probs = candle_nn::ops::log_softmax(&logits_flat, D::Minus1)?; // [S-1, V]
            let nll = log_probs
                .gather(&targets_flat.unsqueeze(D::Minus1)?, D::Minus1)?
                .squeeze(D::Minus1)?; // [S-1]

            let masked_loss = nll.mul(&final_mask_flat.to_dtype(DType::F32)?)?; // [S-1]
            let total_loss = masked_loss.sum_all()?.neg()?; // scalar

            let num_tokens = final_mask_flat
                .sum_all()?
                .to_dtype(DType::F32)?
                .to_scalar::<f32>()?
                .max(1.0);

            let avg_loss = total_loss.div(&Tensor::new(num_tokens, &device)?)?;

            // Back-prop + optimiser step
            // opt.zero_grad()?; // Not needed as Candle accumulates grads per backward call
            let grads = avg_loss.backward()?;
            opt.step(&grads)?;

            // Accumulate loss for epoch reporting
            total_loss_epoch += avg_loss.to_scalar::<f32>()?;
            num_batches_epoch += 1;

            if sample_idx % 100 == 0 {
                println!(
                    "  sample {:>6}  loss {:.4}",
                    sample_idx,
                    avg_loss.to_scalar::<f32>()?
                );
            }

            // Checkpointing logic
            if CHECKPOINT_INTERVAL_MINS > 0 && last_checkpoint_time.elapsed() > checkpoint_interval {
                println!("Saving checkpoint...");
                // Ensure the checkpoint directory exists
                std::fs::create_dir_all(CHECKPOINT_DIR).map_err(candle_core::Error::wrap)?;
                let checkpoint_path = format!("{}/model_epoch{}_sample{}.safetensors", CHECKPOINT_DIR, epoch, sample_idx);
                varmap.save(&checkpoint_path)?;
                println!("Checkpoint saved to {}", checkpoint_path);
                last_checkpoint_time = Instant::now();
            }
        }

        if num_batches_epoch > 0 {
            println!("Epoch {} complete. Average loss: {:.4}", epoch, total_loss_epoch / num_batches_epoch as f32);
        } else {
            println!("Epoch {} complete. No batches processed.", epoch);
        }
    }

    println!("Training finished.");
    Ok(())
}
