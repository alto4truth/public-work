use candle_core::{D, DType, Device, Error, IndexOp, Result, Tensor};
use candle_nn::{
    self, linear, VarBuilder as VB, Module, Activation
};
use candle_nn::encoding;
use crate::constants::{VOCAB_SIZE, HIDDEN_DIM, NUM_HIDDEN_LAYERS, CONTEXT_WINDOW};

// --- Model Definition ---
pub struct TheNn {
    hidden_layers: Vec<candle_nn::Linear>,
    output_layer: candle_nn::Linear,
    activation: Activation,
    span: tracing::Span,
}

impl TheNn {
    pub fn new(
        vb: VB,
        _context_window: usize, // Keep param for potential future use or remove if sure
    ) -> Result<Self> {
        let span = tracing::span!(tracing::Level::TRACE, "TheNn::new");
        let cloned_span = span.clone();
        let _enter = cloned_span.enter();
        
        // --- Dimensions from constants --- 
        let vocab_size = VOCAB_SIZE;
        let hidden_dim = HIDDEN_DIM;
        let num_layers = NUM_HIDDEN_LAYERS;
        // Input dimension calculation: One-hot(vocab_size + 1) + position_scalar(1)
        let first_layer_input_dim = (vocab_size + 1) + 1; // Changed from + hidden_dim

        // Initialize hidden layers
        let mut hidden_layers = Vec::with_capacity(num_layers);
        let hidden_vb = vb.pp("hidden"); // Use a sub-path for hidden layers
        
        // First hidden layer (Input Dim -> Hidden Dim)
        let first_layer_vb = hidden_vb.pp("layer_0");
        // Use the new input dimension
        let first_layer = linear(first_layer_input_dim, hidden_dim, first_layer_vb)?;
        hidden_layers.push(first_layer);

        // Subsequent hidden layers (Hidden Dim -> Hidden Dim)
        for i in 1..num_layers {
            let layer_vb = hidden_vb.pp(format!("layer_{}", i));
            let layer = linear(hidden_dim, hidden_dim, layer_vb)?;
            hidden_layers.push(layer);
        }

        // Output layer (Hidden Dim -> Vocab Size + 1)
        let output_layer = linear(
            hidden_dim,
            vocab_size + 1, // Predict logits for vocab + padding
            vb.pp("output_layer"),
        )?;
        let activation = Activation::Gelu; // Using GeLU activation

        Ok(Self {
            hidden_layers,
            output_layer,
            activation,
            span,
        })
    }

    pub fn forward(&self, input_tokens: &Tensor) -> Result<Tensor> {
        let cloned_span = self.span.clone();
        let _enter = cloned_span.enter();
        let (batch_size, seq_len) = input_tokens.dims2()?;
        let device = input_tokens.device(); // Get device from input

        // 1. One-Hot Encode input tokens (Classes = VOCAB_SIZE + 1)
        let one_hot_input = encoding::one_hot(input_tokens.clone(), VOCAB_SIZE + 1, 1.0f32, 0.0f32)?;
        // Shape: [B, S, V+1]

        // 2. Generate Normalized Positional Scalar
        let positions = Tensor::arange(0u32, seq_len as u32, device)?;
        // Normalize positions to [0.0, 1.0]
        // Using CONTEXT_WINDOW as the max length for normalization divisor
        // Add small epsilon to avoid potential division by zero if CONTEXT_WINDOW is 1 (unlikely)
        let divisor = ((CONTEXT_WINDOW as f32) - 1.0).max(1e-6);
        // Create scalar tensor for divisor
        let divisor_tensor = Tensor::new(divisor, device)?;
        // Explicitly broadcast the divisor tensor to match positions shape before dividing
        let broadcast_divisor = divisor_tensor.broadcast_as(positions.shape())?;
        let normalized_positions = positions.to_dtype(DType::F32)?.div(&broadcast_divisor)?;
        // Reshape and broadcast to match batch and sequence dimensions
        // Shape: [S] -> [1, S, 1] -> [B, S, 1]
        let pos_scalar_tensor = normalized_positions
            .unsqueeze(0)? // [1, S]
            .unsqueeze(D::Minus1)? // [1, S, 1]
            .broadcast_as((batch_size, seq_len, 1))?;
        // Shape: [B, S, 1]

        // 3. Concatenate OHE and Positional Scalar
        let combined_input = Tensor::cat(
            &[
                one_hot_input.to_dtype(DType::F32)?, // Ensure f32
                pos_scalar_tensor, // Already f32
            ],
            D::Minus1, // Concatenate along feature dim
        )?;
        // Shape: [B, S, V+1+1]
        let combined_input = combined_input.contiguous()?;

        // 4. Pass through hidden layers
        let mut hidden_state = combined_input; // Shape: [B, S, V+2]

        // Apply first layer (V+2 -> H)
        if let Some(first_layer) = self.hidden_layers.first() {
            hidden_state = first_layer.forward(&hidden_state)?;
            hidden_state = self.activation.forward(&hidden_state)?;
            // Shape: [B, S, H]
        } else {
            return Err(Error::Msg("Hidden layers vector is empty".to_string()));
        }

        // Apply remaining hidden layers (H -> H)
        for layer in self.hidden_layers.iter().skip(1) {
            hidden_state = layer.forward(&hidden_state)?;
            hidden_state = self.activation.forward(&hidden_state)?;
        }
        // Shape: [B, S, H]

        // 5. Final output layer (H -> V+1)
        let logits = self.output_layer.forward(&hidden_state)?;
        // Shape: [B, S, V+1]

        // 6. Select logits for the last position only for prediction
        let final_logits = logits.i((.., seq_len - 1, ..))?.contiguous()?;
        // Shape: [B, V+1]

        Ok(final_logits)
    }
} 